# rehabilitationAI

**Поточна версія:** `0.16.8`

rehabilitationAI — React + Vite вебзастосунок для домашньої реабілітації з ролями пацієнта і лікаря, AI-аналізом вправ (MediaPipe) та збереженням прогресу у Firebase/Firestore.

## Стек
- Frontend: React, Vite, React Router, i18next
- AI-аналіз руху: MediaPipe Pose Landmarker
- Backend/дані: Firebase Auth + Firestore

## Запуск frontend
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

## Змінні середовища (`frontend/.env`)
```env
VITE_FIREBASE_API_KEY=
VITE_FIREBASE_AUTH_DOMAIN=
VITE_FIREBASE_PROJECT_ID=
VITE_FIREBASE_STORAGE_BUCKET=
VITE_FIREBASE_MESSAGING_SENDER_ID=
VITE_FIREBASE_APP_ID=
```

## Короткий flow
- **Пацієнт:** вхід/реєстрація → Dashboard → окремі вправи або готове заняття → збереження результатів → Progress.
- **Лікар:** Doctor Dashboard → перегляд пацієнтів → сторінка пацієнта з результатами → створення/редагування призначеного плану.

## Firestore collections
`users`, `exerciseResults`, `workoutResults`, `assignedPlans`, `personalPlans`.

## Роль doctor
Роль задається полем `role` у документі користувача в `users` (`"doctor"` для лікаря).

## Важливі обмеження та примітки
- Відео з камери **не зберігається** і **не відправляється** у Firestore; зберігаються лише результати/метадані виконання.
- AI-аналіз у проєкті є **prototype/MVP** і **не є медичною діагностикою**.
- У дипломній версії використано спрощену модель доступу лікаря до пацієнтів. Для production-версії потрібно додати явне закріплення пацієнта за лікарем.
- У поточній версії готове заняття працює як MVP-сценарій, а точність покрокового підрахунку залежить від коректного проходження вправ користувачем.
