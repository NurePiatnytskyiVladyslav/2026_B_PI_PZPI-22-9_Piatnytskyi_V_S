// ---------------------------------
// *Назва файлу: assignedPlansService.js*
// *Опис: Сервіс призначених лікарем планів*
// *Що робить: Працює з отриманням і збереженням планів, призначених пацієнту лікарем*
// ---------------------------------
import {
  addDoc,
  collection,
  doc,
  getDocs,
  query,
  serverTimestamp,
  updateDoc,
  where,
} from "firebase/firestore";
import { db } from "../firebase/firebase";

const getPlanTimestamp = (plan) => {
  if (plan.updatedAt?.toMillis) return plan.updatedAt.toMillis();
  if (plan.createdAt?.toMillis) return plan.createdAt.toMillis();
  return 0;
};

export async function getAssignedPlanByPatientId(patientId) {
  const plansQuery = query(collection(db, "assignedPlans"), where("patientId", "==", patientId));
  const snapshot = await getDocs(plansQuery);

  const activePlans = snapshot.docs
    .map((item) => ({ id: item.id, ...item.data() }))
    .filter((item) => item.status === "active");

  if (activePlans.length === 0) {
    return null;
  }

  return activePlans.sort((a, b) => getPlanTimestamp(b) - getPlanTimestamp(a))[0];
}

export async function createAssignedPlan({ doctorId, patientId, title, description, exercises }) {
  const payload = {
    doctorId,
    patientId,
    title,
    description,
    status: "active",
    exercises,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  const docRef = await addDoc(collection(db, "assignedPlans"), payload);
  return docRef;
}

export async function updateAssignedPlan(planId, data) {
  const planRef = doc(db, "assignedPlans", planId);
  await updateDoc(planRef, {
    title: data.title,
    description: data.description,
    exercises: data.exercises,
    updatedAt: serverTimestamp(),
  });
}