// ---------------------------------
// *Назва файлу: personalPlansService.js*
// *Опис: Сервіс персональних планів пацієнта*
// *Що робить: Працює зі створенням, редагуванням і отриманням персональних планів тренувань*
// ---------------------------------
import {
  addDoc,
  collection,
  doc,
  getDocs,
  query,
  serverTimestamp,
  updateDoc,
  where,
} from "firebase/firestore";
import { db } from "../firebase/firebase";

const getPlanTimestamp = (plan) => {
  if (plan.updatedAt?.toMillis) return plan.updatedAt.toMillis();
  if (plan.createdAt?.toMillis) return plan.createdAt.toMillis();
  return 0;
};

export async function getPersonalPlanByPatientId(patientId) {
  const plansQuery = query(collection(db, "personalPlans"), where("patientId", "==", patientId));
  const snapshot = await getDocs(plansQuery);

  const activePlans = snapshot.docs
    .map((item) => ({ id: item.id, ...item.data() }))
    .filter((item) => item.status === "active");

  if (activePlans.length === 0) {
    return null;
  }

  return activePlans.sort((a, b) => getPlanTimestamp(b) - getPlanTimestamp(a))[0];
}

export async function createPersonalPlan({ patientId, title, days }) {
  const payload = {
    patientId,
    title,
    status: "active",
    days,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  const docRef = await addDoc(collection(db, "personalPlans"), payload);
  return docRef;
}

export async function updatePersonalPlan(planId, data) {
  const planRef = doc(db, "personalPlans", planId);
  await updateDoc(planRef, {
    title: data.title,
    days: data.days,
    updatedAt: serverTimestamp(),
  });
}