// ---------------------------------
// *Назва файлу: userService.js*
// *Опис: Сервіс роботи з даними користувача*
// *Що робить: Виконує запити для створення, отримання та оновлення даних користувача*
// ---------------------------------
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  setDoc,
  where,
  updateDoc,
} from "firebase/firestore";
import { db } from "../firebase/firebase";

const DEFAULT_ROLE = "patient";

function buildUserProfile(user) {
  return {
    uid: user.uid,
    email: user.email || "",
    displayName: user.displayName || "",
    role: DEFAULT_ROLE,
    createdAt: serverTimestamp(),
  };
}

export async function createUserProfileIfNotExists(user) {
  if (!user?.uid) {
    return null;
  }

  const userRef = doc(db, "users", user.uid);
  const snapshot = await getDoc(userRef);

  if (!snapshot.exists()) {
    const profileData = buildUserProfile(user);
    await setDoc(userRef, profileData);
    return {
      uid: profileData.uid,
      email: profileData.email,
      displayName: profileData.displayName,
      role: profileData.role,
      createdAt: null,
    };
  }

  return snapshot.data();
}

export async function getUserProfile(userId) {
  if (!userId) {
    return null;
  }

  const userRef = doc(db, "users", userId);
  const snapshot = await getDoc(userRef);

  if (!snapshot.exists()) {
    return null;
  }

  return { id: snapshot.id, ...snapshot.data() };
}

export async function getPatients() {
  const q = query(collection(db, "users"), where("role", "==", "patient"));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
}


export async function updateUserProblemArea(userId, { problemArea, problemAreaNote }) {
  if (!userId) {
    throw new Error("User ID is required");
  }

  const userRef = doc(db, "users", userId);

  // Оновлення проблемної зони та коментаря пацієнта
  await updateDoc(userRef, {
    problemArea: problemArea || "",
    problemAreaNote: problemAreaNote || "",
    updatedAt: serverTimestamp(),
  });
}