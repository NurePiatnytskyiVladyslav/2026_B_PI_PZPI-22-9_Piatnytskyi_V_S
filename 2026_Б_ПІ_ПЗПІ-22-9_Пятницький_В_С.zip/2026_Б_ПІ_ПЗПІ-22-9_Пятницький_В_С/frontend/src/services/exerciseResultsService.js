// ---------------------------------
// *Назва файлу: exerciseResultsService.js*
// *Опис: Сервіс результатів окремих вправ*
// *Що робить: Зберігає та отримує результати виконання реабілітаційних вправ*
// ---------------------------------
import {
  addDoc,
  collection,
  getDocs,
  query,
  serverTimestamp,
  where,
} from "firebase/firestore";
import { db } from "../firebase/firebase";

export async function saveExerciseResult({
  userId,
  userEmail,
  exerciseId,
  exerciseName,
  reps,
  seconds,
  mainAngle,
  feedback,
  warning,
}) {
  const payload = {
    userId,
    userEmail,
    exerciseId,
    exerciseName,
    reps,
    seconds,
    mainAngle,
    feedback,
    warning,
    createdAt: serverTimestamp(),
  };

  const docRef = await addDoc(collection(db, "exerciseResults"), payload);
  return docRef;
}

export async function getExerciseResultsByUserId(userId) {
  const resultsQuery = query(collection(db, "exerciseResults"), where("userId", "==", userId));
  const snapshot = await getDocs(resultsQuery);

  const results = snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  }));

  const getTime = (item) => (item.createdAt?.toMillis ? item.createdAt.toMillis() : 0);
  return results.sort((a, b) => getTime(b) - getTime(a));
}

export async function getUserExerciseResults(userId) {
  return getExerciseResultsByUserId(userId);
}