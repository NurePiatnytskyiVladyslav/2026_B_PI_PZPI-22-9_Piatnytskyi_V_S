// ---------------------------------
// *Назва файлу: workoutResultsService.js*
// *Опис: Сервіс результатів тренувальних занять*
// *Що робить: Зберігає та отримує результати виконання готових занять*
// ---------------------------------
import { addDoc, collection, getDocs, query, serverTimestamp, where } from "firebase/firestore";
import { db } from "../firebase/firebase";

export async function saveWorkoutResult({
  userId,
  userEmail,
  workoutId,
  workoutName,
  seconds,
  totalTargetReps,
  totalCompletedReps,
  completedExercises,
  source,
  dayKey,
}) {
  const payload = {
    userId,
    userEmail,
    workoutId,
    workoutName,
    seconds,
    totalTargetReps,
    totalCompletedReps,
    completedExercises,
    ...(source ? { source } : {}),
    ...(dayKey ? { dayKey } : {}),
    createdAt: serverTimestamp(),
  };

  Object.keys(payload).forEach((key) => {
    if (payload[key] === undefined) {
      delete payload[key];
    }
  });

  const docRef = await addDoc(collection(db, "workoutResults"), payload);
  return docRef;
}

export async function getWorkoutResultsByUserId(userId) {
  const resultsQuery = query(collection(db, "workoutResults"), where("userId", "==", userId));
  const snapshot = await getDocs(resultsQuery);

  const results = snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  }));

  const getTime = (item) => (item.createdAt?.toMillis ? item.createdAt.toMillis() : 0);
  return results.sort((a, b) => getTime(b) - getTime(a));
}

export async function getUserWorkoutResults(userId) {
  return getWorkoutResultsByUserId(userId);
}