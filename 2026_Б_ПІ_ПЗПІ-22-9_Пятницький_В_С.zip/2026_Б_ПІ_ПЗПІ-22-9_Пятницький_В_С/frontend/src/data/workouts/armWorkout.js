const armWorkout = {
  id: "arm_workout_basic",
  title: "Вправи для рук",
  titleEn: "Arm exercises",
  description: "Базове заняття для м’якої реабілітації рук і плечового поясу",
  descriptionEn: "Basic session for gentle rehabilitation of arms and shoulders",
  exercises: [
    { exerciseId: "right_biceps", reps: 8 },
    { exerciseId: "left_biceps", reps: 8 },
    { exerciseId: "right_arm_raise", reps: 8 },
    { exerciseId: "left_arm_raise", reps: 8 },
    { exerciseId: "right_arm_raise_front", reps: 6 },
    { exerciseId: "left_arm_raise_front", reps: 6 },
    { exerciseId: "right_shoulder_press", reps: 6 },
    { exerciseId: "left_shoulder_press", reps: 6 },
    { exerciseId: "both_arms_up", reps: 8 },
    { exerciseId: "both_biceps", reps: 8 },
  ],
};

export default armWorkout;
