const legWorkout = {
  id: "leg_workout_basic",
  title: "Вправи для ніг",
  titleEn: "Leg exercises",
  description: "Базове заняття для реабілітації ніг, колін і тазостегнових суглобів",
  descriptionEn: "Basic session for rehabilitation of legs, knees, and hips",
  exercises: [
    { exerciseId: "right_knee_raise", reps: 8 },
    { exerciseId: "left_knee_raise", reps: 8 },
    { exerciseId: "right_knee_extension", reps: 8 },
    { exerciseId: "left_knee_extension", reps: 8 },
    { exerciseId: "right_leg_side_raise", reps: 6 },
    { exerciseId: "left_leg_side_raise", reps: 6 },
    { exerciseId: "right_leg_back_raise", reps: 6 },
    { exerciseId: "left_leg_back_raise", reps: 6 },
    { exerciseId: "heel_raise", reps: 10 },
    { exerciseId: "half_squat_rehab", reps: 8 },
    { exerciseId: "marching_in_place", reps: 10 },
  ],
};

export default legWorkout;
