const neckWorkout = {
  id: "neck_workout_basic",
  title: "Вправи для шиї",
  titleEn: "Neck exercises",
  description: "Базове заняття для мобільності та м’якої реабілітації шиї",
  descriptionEn: "Basic session for mobility and gentle rehabilitation of the neck",
  exercises: [
    { exerciseId: "neck_flexion", reps: 8 },
    { exerciseId: "neck_extension", reps: 8 },
    { exerciseId: "neck_side_left", reps: 6 },
    { exerciseId: "neck_side_right", reps: 6 },
    { exerciseId: "neck_chin_tuck", reps: 8 },
  ],
};

export default neckWorkout;
