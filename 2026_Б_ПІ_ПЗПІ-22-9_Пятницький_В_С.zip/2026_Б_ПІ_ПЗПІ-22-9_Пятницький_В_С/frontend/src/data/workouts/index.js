// ---------------------------------
// *Назва файлу: index.js*
// *Опис: Модуль готових тренувальних занять*
// *Що робить: Містить набір готових тренувань і структуру вправ у кожному занятті*
// ---------------------------------
import neckWorkout from "./neckWorkout";
import armWorkout from "./armWorkout";
import legWorkout from "./legWorkout";
import backWorkout from "./backWorkout";

const workouts = [
  neckWorkout,
  armWorkout,
  legWorkout,
  backWorkout,
];

export default workouts;