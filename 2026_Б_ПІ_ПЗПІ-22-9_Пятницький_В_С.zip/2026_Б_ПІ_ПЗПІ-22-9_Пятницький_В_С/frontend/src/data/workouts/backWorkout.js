const backWorkout = {
  id: "back_workout_basic",
  title: "Вправи для спини",
  titleEn: "Back exercises",
  description: "Базове заняття для мобільності спини та м’якої реабілітації корпусу",
  descriptionEn: "Basic session for back mobility and gentle core rehabilitation",
  exercises: [
    { exerciseId: "body_bend", reps: 10 },
    { exerciseId: "back_side_bend_left", reps: 8 },
  ],
};

export default backWorkout;
