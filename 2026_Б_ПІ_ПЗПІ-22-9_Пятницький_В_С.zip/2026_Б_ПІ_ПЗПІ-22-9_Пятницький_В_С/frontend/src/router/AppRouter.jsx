// ---------------------------------
// *Назва файлу: AppRouter.jsx*
// *Опис: Модуль маршрутизації застосунку*
// *Що робить: Описує маршрути сторінок і правила доступу до них*
// ---------------------------------
import { Routes, Route } from "react-router-dom";
import HomePage from "../pages/HomePage";
import DashboardPage from "../pages/DashboardPage";
import ExercisePage from "../pages/ExercisePage";
import ProtectedRoute from "../components/ProtectedRoute";
import WorkoutSessionPage from "../pages/WorkoutSessionPage";
import ProgressPage from "../pages/ProgressPage";
import WeeklyPlanPage from "../pages/WeeklyPlanPage";
import DoctorDashboardPage from "../pages/DoctorDashboardPage";
import DoctorPatientProgressPage from "../pages/DoctorPatientProgressPage";
import DoctorConnectionPage from "../pages/DoctorConnectionPage";
import PersonalWorkoutSessionPage from "../pages/PersonalWorkoutSessionPage";

function AppRouter() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />

      <Route
        path="/dashboard"
        element={<ProtectedRoute allowedRoles={["patient"]}><DashboardPage /></ProtectedRoute>}
      />

      <Route
        path="/exercise/:slug"
        element={<ProtectedRoute allowedRoles={["patient"]}><ExercisePage /></ProtectedRoute>}
      />

      <Route
        path="/workout/:slug"
        element={<ProtectedRoute allowedRoles={["patient"]}><WorkoutSessionPage /></ProtectedRoute>}
      />

      <Route
        path="/plan"
        element={<ProtectedRoute allowedRoles={["patient"]}><WeeklyPlanPage /></ProtectedRoute>}
      />


      <Route
        path="/personal-workout/:dayKey"
        element={<ProtectedRoute allowedRoles={["patient"]}><PersonalWorkoutSessionPage /></ProtectedRoute>}
      />

      <Route
        path="/doctor-connection"
        element={<ProtectedRoute allowedRoles={["patient"]}><DoctorConnectionPage /></ProtectedRoute>}
      />

      <Route
        path="/doctor"
        element={<ProtectedRoute allowedRoles={["doctor"]}><DoctorDashboardPage /></ProtectedRoute>}
      />

      <Route
        path="/doctor/patient/:patientId"
        element={<ProtectedRoute allowedRoles={["doctor"]}><DoctorPatientProgressPage /></ProtectedRoute>}
      />

      <Route
        path="/progress"
        element={<ProtectedRoute allowedRoles={["patient"]}><ProgressPage /></ProtectedRoute>}
      />
    </Routes>
  );
}

export default AppRouter;