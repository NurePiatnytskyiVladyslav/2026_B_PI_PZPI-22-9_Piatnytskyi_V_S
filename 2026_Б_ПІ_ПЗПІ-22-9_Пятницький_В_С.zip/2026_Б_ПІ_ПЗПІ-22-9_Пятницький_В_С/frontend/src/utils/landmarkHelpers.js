// ---------------------------------
// *Назва файлу: landmarkHelpers.js*
// *Опис: Утиліти для роботи з landmarks*
// *Що робить: Надає допоміжні функції для обробки та перевірки координат точок тіла*
// ---------------------------------
export const isLandmarkVisible = (landmark, minVisibility = 0.5) => {
  if (!landmark) return false;

  const hasVisibility = typeof landmark.visibility === "number";
  const hasPresence = typeof landmark.presence === "number";

  if (!hasVisibility && !hasPresence) {
    return true;
  }

  const visibilityOk = !hasVisibility || landmark.visibility >= minVisibility;
  const presenceOk = !hasPresence || landmark.presence >= minVisibility;

  return visibilityOk && presenceOk;
};

export const areLandmarksVisible = (landmarks, minVisibility = 0.5) => {
  if (!Array.isArray(landmarks) || landmarks.length === 0) return false;

  return landmarks.every((landmark) =>
    isLandmarkVisible(landmark, minVisibility),
  );
};