const motionTextKeyMap = {
  "Очікую правильне положення перед камерою": "motion.waitingCorrectPosition",
  "Очікую правильне положення": "motion.waitingCorrectPositionShort",
  "Потрібні точки тіла погано видно": "motion.requiredBodyPointsNotVisible",
  "Виконуй вправу": "motion.performExercise",
  "Рух хороший": "motion.goodMovement",
  "Рух виконано добре": "motion.goodMovementDone",
  "Збільшіть амплітуду руху": "motion.increaseRange",
  "Недостатня амплітуда руху": "motion.lowRange",
  "Стань так, щоб руку було краще видно": "motion.standSoArmVisible",
  "Стань так, щоб ліву руку було краще видно": "motion.standSoLeftArmVisible",
  "Стань так, щоб праву руку було краще видно": "motion.standSoRightArmVisible",
  "Стань так, щоб обидві руки було краще видно": "motion.standSoBothArmsVisible",
  "Стань так, щоб обидві руки було видно": "motion.standSoBothArmsVisibleSimple",
  "Підніми руку трохи вище": "motion.raiseArmHigher",
  "Тримайте плечі рівно": "motion.keepShouldersLevel",
  "Сядьте так, щоб було видно обличчя і плечі": "motion.sitSoFaceAndShouldersVisible",
  "Сядьте рівно ближче до камери": "motion.sitStraightCloserToCamera",
  "Руки вгорі, тепер опускай.": "motion.armsUpNowLower",
  "Руки внизу, піднімай вгору.": "motion.armsDownRaiseUp",
  "Піднімай та опускай руки плавно.": "motion.raiseLowerArmsSmoothly",
  "Повтор зараховано!": "motion.repCounted",
  "Повтор зараховано": "motion.repCounted",
  "Повторення зараховано!": "motion.repCounted",
  "Повторення зараховано": "motion.repCounted",
  "Недостатньо точок для аналізу підйому обох рук": "motion.notEnoughPointsBothArmsUp",
  "Недостатньо точок для аналізу підйому руки": "motion.notEnoughPointsArmRaise",
  "Недостатньо точок для аналізу підйому лівої руки": "motion.notEnoughPointsLeftArmRaise",
  "Недостатньо точок для аналізу підйому правої руки вперед": "motion.notEnoughPointsRightArmRaiseFront",
  "Недостатньо точок для аналізу підйому лівої руки вперед": "motion.notEnoughPointsLeftArmRaiseFront",
  "Недостатньо точок для аналізу згинання обох рук": "motion.notEnoughPointsBothBiceps",
  "Недостатньо точок для аналізу правої руки": "motion.notEnoughPointsRightArm",
  "Недостатньо точок для аналізу лівої руки": "motion.notEnoughPointsLeftArm",
  "Недостатньо точок для аналізу присідання": "motion.notEnoughPointsSquat",
  "Недостатньо точок для аналізу напівприсідання": "motion.notEnoughPointsHalfSquat",
  "Недостатньо точок для аналізу нахилу корпусу": "motion.notEnoughPointsBodyBend",
  "Недостатньо точок для аналізу бічного нахилу корпусу вліво": "motion.notEnoughPointsBackSideBendLeft",
  "Недостатньо точок для аналізу кроку на місці": "motion.notEnoughPointsMarchingInPlace",
  "Недостатньо точок для аналізу підйому на носки": "motion.notEnoughPointsHeelRaise",
  "Недостатньо точок для аналізу підйому правого коліна": "motion.notEnoughPointsRightKneeRaise",
  "Недостатньо точок для аналізу підйому лівого коліна": "motion.notEnoughPointsLeftKneeRaise",
  "Недостатньо точок для аналізу розгинання правого коліна": "motion.notEnoughPointsRightKneeExtension",
  "Недостатньо точок для аналізу розгинання лівого коліна": "motion.notEnoughPointsLeftKneeExtension",
  "Недостатньо точок для аналізу відведення правої ноги": "motion.notEnoughPointsRightLegSideRaise",
  "Недостатньо точок для аналізу відведення лівої ноги": "motion.notEnoughPointsLeftLegSideRaise",
  "Недостатньо точок для аналізу відведення правої ноги назад": "motion.notEnoughPointsRightLegBackRaise",
  "Недостатньо точок для аналізу відведення лівої ноги назад": "motion.notEnoughPointsLeftLegBackRaise",
  "Недостатньо точок для аналізу жиму правою рукою": "motion.notEnoughPointsRightShoulderPress",
  "Недостатньо точок для аналізу жиму лівою рукою": "motion.notEnoughPointsLeftShoulderPress",
  "Недостатньо точок для аналізу нахилу голови вперед": "motion.notEnoughPointsNeckFlexion",
  "Недостатньо точок для аналізу нахилу голови назад": "motion.notEnoughPointsNeckExtension",
  "Недостатньо точок для аналізу вправи підборіддя до шиї": "motion.notEnoughPointsNeckChinTuck",
  "Добре! Тепер розгинай руку.": "motion.goodNowExtendArm",
  "Добре! Тепер плавно розгинай обидві руки.": "motion.goodNowExtendBothArms",
  "Руки розігнуті, тепер згинай обидві.": "motion.armsExtendedNowBendBoth",
  "Продовжуй рух обома руками.": "motion.continueBothArms",
  "Рука розігнута, тепер згинай.": "motion.armExtendedNowBend",
  "Продовжуй рух.": "motion.continueMovement",

  "Піднімай або опускай руку плавно.": "motion.raiseLowerArmSmoothly",
  "Рука внизу, піднімай в сторону.": "motion.armDownRaiseSide",
  "Рука піднята, тепер опускай.": "motion.armUpNowLower",
  "Недостатньо точок для аналізу правого коліна": "motion.notEnoughPointsRightKnee",
  "Рука зігнута, тепер розгинай.": "motion.armBentNowExtend",
  "Рука внизу, піднімай вперед.": "motion.armDownRaiseForward",
  "Рука піднята вперед, тепер опускай.": "motion.armRaisedForwardNowLower",
  "Рука майже пряма, тепер опускай.": "motion.armAlmostStraightNowLower",
  "Рука зігнута, виштовхуй вгору.": "motion.armBentPushUp",
  "Нога опущена, піднімай коліно.": "motion.legLoweredRaiseKnee",
  "Нога внизу, піднімай коліно.": "motion.legDownRaiseKnee",
  "Коліно підняте, тепер опускай.": "motion.kneeRaisedNowLower",
  "Коліно зігнуте, тепер розгинай.": "motion.kneeBentNowExtend",
  "Нога розігнута, тепер згинай.": "motion.legExtendedNowBend",
  "Повернися у початкове положення.": "motion.returnStartPosition",
  "Поверніться у нейтральне положення": "motion.returnNeutralPosition",
  "Позицію виконано, повернися у нейтральне положення.": "motion.positionDoneReturnNeutral",
  "Продовжуй рух плавно.": "motion.continueMovementSmoothly",
  "Рухайся плавно.": "motion.moveSmoothly",
  "Рухайся повільно та без ривків.": "motion.moveSlowlyNoJerks",
  "Контролюй спину та рухайся плавно.": "motion.controlBackMoveSmoothly",
  "Стоїш рівно, тепер присідай.": "motion.standingStraightSquat",
  "Тіло випрямлене, починай присідати.": "motion.bodyStraightStartSquat",
  "Добре! Тепер піднімайся.": "motion.goodNowStandUp",
  "Нижня точка, тепер піднімайся.": "motion.bottomPointNowStandUp",
  "Тримай рівний темп руху.": "motion.keepEvenMovementPace",
  "Стоїш рівно, тепер нахиляйся вперед.": "motion.standingStraightBendForward",
  "Нахил виконано, повертайся назад.": "motion.bendDoneReturnBack",
  "Корпус рівно, нахиляйся вліво.": "motion.trunkStraightBendLeft",
  "Нахил виконано, повернися у вихідне положення.": "motion.bendDoneReturnStart",
  "Нога біля корпусу, відводь у сторону.": "motion.legNearBodyMoveSide",
  "Нога відведена, тепер повертай назад.": "motion.legRaisedSideReturnBack",
  "Нога внизу, відводь назад.": "motion.legDownMoveBack",
  "Нога відведена назад, повертай назад повільно.": "motion.legBackRaisedReturnSlowly",
  "Ноги внизу, піднімай коліно для кроку.": "motion.legsDownRaiseKneeStep",
  "Коліно підняте, опускай та продовжуй крок.": "motion.kneeRaisedLowerContinueStep",
  "Рухайся плавно в ритмі кроку.": "motion.moveSmoothlyStepRhythm",
  "П’яти внизу, піднімайся на носки.": "motion.heelsDownRiseToToes",
  "Ти на носках, повільно опускайся.": "motion.onToesLowerSlowly",
  "Голова рівно, нахиляй вперед.": "motion.headStraightTiltForward",
  "Голова нахилена, поверни назад.": "motion.headBentReturnBack",
  "Голова прямо, відхиляй назад.": "motion.headStraightTiltBack",
  "Голова назад, поверни вперед.": "motion.headBackReturnForward",
  "Голова нейтрально, м’яко потягни підборіддя назад.": "motion.headNeutralChinTuckBack",
};

const repCountedPrefix = "Повтор зараховано!";

const localizeKnownText = (text, t) => {
  const key = motionTextKeyMap[text.trim()];
  if (!key) return null;
  return t ? t(key) : text;
};

const localizeAngleText = (text, t) => {
  const angleMatch = text.match(/^(.*)\sКут:\s(.+)$/);
  if (!angleMatch) return null;

  const [, baseText, angle] = angleMatch;
  const baseLocalized = localizeKnownText(baseText, t);
  if (baseLocalized) {
    return `${baseLocalized} Angle: ${angle}`;
  }

  return text.replace("Кут:", "Angle:");
};

const localizeMotionSegment = (text, t) => {
  return localizeAngleText(text, t) || localizeKnownText(text, t) || text;
};

export function localizeMotionText(text, language, t) {
  if (!text) return text;
  if (language !== "en") return text;

  if (text.startsWith(repCountedPrefix)) {
    const prefixLocalized = t ? t("motion.repCounted") : "Repetition counted!";
    const tail = text.slice(repCountedPrefix.length).trim();

    if (!tail) return prefixLocalized;

    return `${prefixLocalized} ${localizeMotionSegment(tail, t)}`;
  }

  return localizeMotionSegment(text, t);
}
