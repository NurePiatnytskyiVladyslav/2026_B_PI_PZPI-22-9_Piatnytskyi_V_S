// ---------------------------------
// *Назва файлу: formatDate.js*
// *Опис: Утиліта форматування дат*
// *Що робить: Перетворює дати у зручний для інтерфейсу формат відображення*
// ---------------------------------
// Хелпер форматує Date/Firestore Timestamp відповідно до активної мови інтерфейсу
export function formatDate(value, language = "ua", options) {
  if (!value) return "-";

  const date = value?.toDate ? value.toDate() : new Date(value);
  if (Number.isNaN(date.getTime())) return "-";

  const locale = language === "en" ? "en-US" : "uk-UA";
  return date.toLocaleString(locale, options);
}