const CATEGORY_BY_EXERCISE_ID = {
  // arms / hands
  rightBiceps: "arm",
  leftBiceps: "arm",
  rightArmRaise: "arm",
  leftArmRaise: "arm",
  bothArmsUp: "arm",
  rightArmRaiseFront: "arm",
  leftArmRaiseFront: "arm",
  rightShoulderPress: "arm",
  leftShoulderPress: "arm",
  bothBiceps: "arm",

  // legs
  squat: "leg",
  halfSquatRehab: "leg",
  rightKneeRaise: "leg",
  leftKneeRaise: "leg",
  rightKneeExtension: "leg",
  leftKneeExtension: "leg",
  rightLegSideRaise: "leg",
  leftLegSideRaise: "leg",
  rightLegBackRaise: "leg",
  leftLegBackRaise: "leg",
  rightHipMarch: "leg",
  leftHipMarch: "leg",
  heelRaise: "leg",
  marchingInPlace: "leg",

  // back
  bodyBend: "back",
  backSideBendLeft: "back",

  // neck
  neckFlexion: "neck",
  neckExtension: "neck",
  neckSideLeft: "neck",
  neckSideRight: "neck",
  neckChinTuck: "neck",
};

const GUIDANCE_TEXTS = {
  ua: {
    start: "Займіть початкове положення перед камерою.",
    up: "Поверніться у початкове положення.",
    down: "Виконуйте рух повільно та контрольовано.",
    generic: "Виконуйте вправу повільно та слідкуйте за положенням тіла.",
    arm: {
      primary: "Згинайте руку повільно та контролюйте рух.",
      stable: "Тримайте плече стабільно.",
      visibility: "Станьте так, щоб руку було добре видно.",
    },
    leg: {
      primary: "Піднімайте ногу повільно та без різких рухів.",
      stable: "Тримайте корпус рівно.",
      visibility: "Станьте так, щоб ногу було добре видно.",
    },
    neck: {
      primary: "Рухайте головою повільно та без різких рухів.",
      stable: "Тримайте плечі рівно.",
      visibility: "Сядьте так, щоб було видно обличчя і плечі.",
      up: "Поверніться у нейтральне положення.",
    },
    back: {
      primary: "Виконуйте нахил повільно та контрольовано.",
      stable: "Тримайте рух плавним.",
      down: "Не робіть різких рухів.",
    },
  },
  en: {
    start: "Take the starting position in front of the camera.",
    up: "Return to the starting position.",
    down: "Move slowly and stay controlled.",
    generic: "Perform the exercise slowly and follow your body position.",
    arm: {
      primary: "Bend your arm slowly and control the movement.",
      stable: "Keep your shoulder stable.",
      visibility: "Stand so your arm is clearly visible.",
    },
    leg: {
      primary: "Raise your leg slowly without sudden movements.",
      stable: "Keep your torso straight.",
      visibility: "Stand so your leg is clearly visible.",
    },
    neck: {
      primary: "Move your head slowly without sudden movements.",
      stable: "Keep your shoulders level.",
      visibility: "Sit so your face and shoulders are visible.",
      up: "Return to the neutral position.",
    },
    back: {
      primary: "Bend slowly and keep the movement controlled.",
      stable: "Keep the movement smooth.",
      down: "Avoid sudden movements.",
    },
  },
};

const WARNING_VISIBILITY_MARKERS = ["погано видно", "not visible", "visibility", "видно", "landmark"];

const normalizeLang = (language) => (language === "en" ? "en" : "ua");

const detectCategory = ({ exerciseId, exerciseName = "" }) => {
  if (exerciseId && CATEGORY_BY_EXERCISE_ID[exerciseId]) {
    return CATEGORY_BY_EXERCISE_ID[exerciseId];
  }

  const normalized = String(exerciseName).toLowerCase();

  if (/(neck|ши|голов|chin)/.test(normalized)) return "neck";
  if (/(back|спин|bend|нахил)/.test(normalized)) return "back";
  if (/(leg|knee|hip|squat|ног|колін|heel|march)/.test(normalized)) return "leg";
  if (/(arm|bicep|shoulder|рук|плеч)/.test(normalized)) return "arm";

  return null;
};

const isVisibilityIssue = (text = "") => {
  const lower = String(text).toLowerCase();
  return WARNING_VISIBILITY_MARKERS.some((marker) => lower.includes(marker));
};

export function getExerciseGuidance({
  exerciseId,
  exerciseName,
  stage,
  feedback,
  warning,
  language,
}) {
  const lang = normalizeLang(language);
  const category = detectCategory({ exerciseId, exerciseName });
  const dictionary = GUIDANCE_TEXTS[lang];

  if (stage === "start" || !stage) {
    return dictionary.start;
  }

  if (stage === "up") {
    if (category === "neck") {
      return dictionary.neck.up;
    }
    return dictionary.up;
  }

  if (stage === "down") {
    if (category === "back") {
      return dictionary.back.down;
    }
    if (category && dictionary[category]?.primary) {
      return dictionary[category].primary;
    }
    return dictionary.down;
  }

  if (category && dictionary[category]?.primary) {
    if (isVisibilityIssue(feedback) || isVisibilityIssue(warning)) {
      return dictionary[category].visibility || dictionary[category].primary;
    }

    if (stage === "hold") {
      return dictionary[category].stable || dictionary[category].primary;
    }

    return dictionary[category].primary;
  }

  return dictionary.generic;
}

export default getExerciseGuidance;
