// ---------------------------------
// *Назва файлу: ProgressPage.jsx*
// *Опис: Сторінка прогресу пацієнта*
// *Що робить: Відображає статистику результатів вправ і занять у динаміці*
// ---------------------------------
import { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import Header from "../components/Header";
import { useAuth } from "../context/useAuth";
import { getUserExerciseResults } from "../services/exerciseResultsService";
import { getUserWorkoutResults } from "../services/workoutResultsService";
import { formatDate } from "../utils/formatDate";
import exercises from "../exercises";
import { localizeMotionText } from "../utils/localizeMotionText";

function ProgressPage() {
  const { user } = useAuth();
  const { t, i18n } = useTranslation();
  const [exerciseResults, setExerciseResults] = useState([]);
  const [workoutResults, setWorkoutResults] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadResults() {
      if (!user?.uid) {
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError("");

        const [userExerciseResults, userWorkoutResults] = await Promise.all([
          getUserExerciseResults(user.uid),
          getUserWorkoutResults(user.uid),
        ]);

        setExerciseResults(userExerciseResults);
        setWorkoutResults(userWorkoutResults);
      } catch (err) {
        console.error("Помилка завантаження прогресу:", err);
        setError(t("progress.loadError"));
      } finally {
        setIsLoading(false);
      }
    }

    loadResults();
  }, [t, user]);



  const findExerciseById = (exerciseId) => exercises.find((exercise) => exercise.id === exerciseId);

  const getLocalizedExerciseName = useCallback((exerciseId, fallbackName) => {
    const found = findExerciseById(exerciseId);
    if (found) return i18n.language === "en" && found.nameEn ? found.nameEn : found.name;
    return fallbackName || exerciseId || t("progress.unnamedExercise");
  }, [i18n.language, t]);

  const stats = useMemo(() => {
    const totalExerciseResults = exerciseResults.length;
    const totalWorkoutResults = workoutResults.length;

    const totalRepetitions = exerciseResults.reduce((sum, result) => sum + (result.reps ?? 0), 0)
      + workoutResults.reduce((sum, result) => sum + (result.totalCompletedReps ?? 0), 0);

    const totalSeconds = exerciseResults.reduce((sum, result) => sum + (result.seconds ?? 0), 0)
      + workoutResults.reduce((sum, result) => sum + (result.seconds ?? 0), 0);

    const allDates = [...exerciseResults, ...workoutResults]
      .map((result) => {
        if (!result.createdAt) return null;

        const date = result.createdAt.toDate ? result.createdAt.toDate() : new Date(result.createdAt);
        return Number.isNaN(date.getTime()) ? null : date;
      })
      .filter(Boolean);

    const lastActivity = allDates.length
      ? new Date(Math.max(...allDates.map((date) => date.getTime())))
      : null;

    const exerciseCounts = {};

    exerciseResults.forEach((result) => {
      const name = getLocalizedExerciseName(result.exerciseId, result.exerciseName)?.trim();
      if (!name) return;
      exerciseCounts[name] = (exerciseCounts[name] || 0) + 1;
    });

    workoutResults.forEach((result) => {
      (result.completedExercises || []).forEach((exercise) => {
        const name = getLocalizedExerciseName(exercise.exerciseId, exercise.exerciseName)?.trim();
        if (!name) return;
        exerciseCounts[name] = (exerciseCounts[name] || 0) + 1;
      });
    });

    const mostFrequentExercise = Object.entries(exerciseCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || null;

    return {
      totalExerciseResults,
      totalWorkoutResults,
      totalRepetitions,
      totalSeconds,
      lastActivity,
      mostFrequentExercise,
    };
  }, [exerciseResults, workoutResults, getLocalizedExerciseName]);

  const formatDuration = (seconds = 0) => {
    if (seconds < 60) return `${seconds} ${t("progress.secondsShort")}`;

    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;

    return `${String(minutes).padStart(2, "0")}:${String(remainingSeconds).padStart(2, "0")}`;
  };

  const hasNoResults = exerciseResults.length === 0 && workoutResults.length === 0;
  return (
    <>
      <Header />

      <main className="progress-page">
        <div className="container">
          <div className="page-top-actions">
            <Link to="/dashboard" className="exercise-back-link exercise-back-link--ui">
              ← {t("common.backToDashboard")}
            </Link>
          </div>

          <h1>{t("progress.title")}</h1>

          {isLoading && <p className="app-state app-state--loading">{t("common.loading")}</p>}

          {!isLoading && error && <p className="app-state app-state--error">{error || t("common.error")}</p>}

          {!isLoading && !error && hasNoResults && <p className="app-state app-state--empty">{t("common.noData")}</p>}

          {!isLoading && !error && !hasNoResults && (
            <div className="progress-list">
              <section className="progress-section">
                <h2 className="progress-section-title">{t("progress.overallStatistics")}</h2>
                <div className="progress-stats-grid">
                  <article className="progress-stat-card">
                    <p className="progress-stat-label">{t("progress.exerciseResults")}</p>
                    <p className="progress-stat-value">{stats.totalExerciseResults}</p>
                  </article>
                  <article className="progress-stat-card">
                    <p className="progress-stat-label">{t("progress.workoutResults")}</p>
                    <p className="progress-stat-value">{stats.totalWorkoutResults}</p>
                  </article>
                  <article className="progress-stat-card">
                    <p className="progress-stat-label">{t("progress.totalRepetitions")}</p>
                    <p className="progress-stat-value">{stats.totalRepetitions}</p>
                  </article>
                  <article className="progress-stat-card">
                    <p className="progress-stat-label">{t("progress.totalTimeLabel")}</p>
                    <p className="progress-stat-value">{formatDuration(stats.totalSeconds)}</p>
                  </article>
                  <article className="progress-stat-card">
                    <p className="progress-stat-label">{t("progress.lastActivity")}</p>
                    <p className="progress-stat-value">{stats.lastActivity ? formatDate(stats.lastActivity, i18n.language) : t("progress.noData")}</p>
                  </article>
                  <article className="progress-stat-card">
                    <p className="progress-stat-label">{t("progress.mostFrequentExercise")}</p>
                    <p className="progress-stat-value">{stats.mostFrequentExercise || t("progress.noData")}</p>
                  </article>
                </div>
              </section>
              <section className="progress-section">
                <h2 className="progress-section-title">{t("progress.exerciseResults")}</h2>

                {exerciseResults.length === 0 ? (
                  <p className="progress-empty">{t("progress.empty")}</p>
                ) : (
                  <>
                    <p className="progress-count">{t("progress.found", { count: exerciseResults.length })}</p>
                    {exerciseResults.map((result) => (
                      <article key={result.id} className="progress-card">
                        <h2>{getLocalizedExerciseName(result.exerciseId, result.exerciseName)}</h2>
                        <div className="progress-meta-grid">
                          <p>
                            <strong>{t("progress.date")}:</strong> {formatDate(result.createdAt, i18n.language)}
                          </p>
                          <p>
                            <strong>{t("progress.reps")}:</strong> {result.reps ?? 0}
                          </p>
                          <p>
                            <strong>{t("progress.seconds")}:</strong> {result.seconds ?? 0}
                          </p>
                          <p>
                            <strong>{t("progress.angle")}:</strong> {result.mainAngle ?? "—"}
                          </p>
                        </div>
                        <p className="progress-feedback">
                          <strong>{t("progress.feedback")}:</strong> {localizeMotionText(result.feedback, i18n.language, t) || "—"}
                        </p>
                        {result.warning && (
                          <p className="progress-warning">
                            <strong>{t("progress.warning")}:</strong> {localizeMotionText(result.warning, i18n.language, t)}
                          </p>
                        )}
                      </article>
                    ))}
                  </>
                )}
              </section>

              <section className="progress-section">
                <h2 className="progress-section-title">{t("progress.workoutResults")}</h2>

                {workoutResults.length === 0 ? (
                  <p className="progress-empty">{t("progress.noSavedWorkouts")}</p>
                ) : (
                  workoutResults.map((result) => (
                    <article key={result.id} className="workout-result-card">
                      <h3>{result.workoutName || t("progress.unnamedWorkout")}</h3>
                      <div className="progress-meta-grid">
                        <p>
                          <strong>{t("progress.date")}:</strong> {formatDate(result.createdAt, i18n.language)}
                        </p>
                        <p>
                          <strong>{t("progress.totalTime")}:</strong> {result.seconds ?? 0}
                        </p>
                        <p>
                          <strong>{t("progress.completedRepetitions")}:</strong> {result.totalCompletedReps ?? 0}
                        </p>
                        <p>
                          <strong>{t("progress.targetRepetitions")}:</strong> {result.totalTargetReps ?? 0}
                        </p>
                      </div>

                      <div className="workout-result-exercises">
                        <p>
                          <strong>{t("progress.completedExercises")}:</strong>
                        </p>
                        {(result.completedExercises || []).map((exercise, index) => (
                          <p key={`${result.id}-${exercise.exerciseId || index}`} className="workout-result-exercise-item">
                            {getLocalizedExerciseName(exercise.exerciseId, exercise.exerciseName)} — {exercise.completedReps ?? 0} / {exercise.targetReps ?? 0}
                          </p>
                        ))}
                      </div>
                    </article>
                  ))
                )}
              </section>
            </div>
          )}
        </div>
      </main>
    </>
  );
}

export default ProgressPage;
