// ---------------------------------
// *Назва файлу: WorkoutSessionPage.jsx*
// *Опис: Сторінка виконання готового заняття з набором вправ*
// *Що робить: Проводить користувача через плейліст вправ, аналізує виконання через MediaPipe та зберігає результат заняття*
// ---------------------------------
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import Header from "../components/Header";
import rehabExercises from "../exercises/index.js";
import workouts from "../data/workouts/index.js";
import usePoseDetection from "../hooks/usePoseDetection";
import { useAuth } from "../context/useAuth";
import { saveWorkoutResult } from "../services/workoutResultsService";
import { localizeMotionText } from "../utils/localizeMotionText";
import { getExerciseGuidance } from "../utils/getExerciseGuidance";
import useStableValue from "../hooks/useStableValue";

function formatTime(totalSeconds) {
  const mins = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const secs = String(totalSeconds % 60).padStart(2, "0");
  return `${mins}:${secs}`;
}

function normalizeAnalyzeResult(result) {
  if (typeof result === "string") {
    return {
      message: result,
      feedback: "",
      warning: "",
    };
  }

  if (result && typeof result === "object") {
    return {
      message: result.message || "",
      feedback: result.feedback || "",
      warning: result.warning || "",
    };
  }

  return {
    message: "no analysis yet",
    feedback: "",
    warning: "",
  };
}

function WorkoutSessionPageContent({ slug }) {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();

  const workout = workouts.find((item) => item.id === slug);
  const getExerciseName = useCallback(
    (exercise) => {
      if (!exercise) return t("common.notAvailable");
      return i18n.language === "en" ? exercise.nameEn || exercise.name : exercise.name;
    },
    [i18n.language, t],
  );
  const getExerciseDescription = (exercise) => {
    if (!exercise) return t("dashboard.exerciseDescriptionFallback");
    if (i18n.language === "en") {
      return exercise.descriptionEn || t("dashboard.exerciseDescriptionFallback");
    }
    return exercise.description || t("dashboard.exerciseDescriptionFallback");
  };

  const [editableSteps, setEditableSteps] = useState(
    () => workout?.exercises?.map((step) => ({ ...step })) || [],
  );

  const [isWorkoutStarted, setIsWorkoutStarted] = useState(false);
  const [isWorkoutCompleted, setIsWorkoutCompleted] = useState(false);
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);

  const [seconds, setSeconds] = useState(0);
  const [saveState, setSaveState] = useState("idle");
  const [isSavingResult, setIsSavingResult] = useState(false);
  const [isWorkoutResultSaved, setIsWorkoutResultSaved] = useState(false);

  const cameraSectionRef = useRef(null);
  const isChangingExerciseRef = useRef(false);
  const changeExerciseTimeoutRef = useRef(null);

  const currentStep = editableSteps[currentExerciseIndex] || null;

  const currentExercise = useMemo(() => {
    if (!currentStep) return null;

    return rehabExercises.find((item) => item.id === currentStep.exerciseId);
  }, [currentStep]);

  // Аналізуємо позу саме для поточної вправи в занятті
  const analyzePose = useCallback(
    ({ landmarks, stageRef, lastRepTimeRef, setMainAngle, setExerciseStage, setReps }) => {
      if (!landmarks || landmarks.length === 0) {
        setMainAngle(0);
        setExerciseStage("start");
        stageRef.current = "start";

        return { message: t("exercise.humanNotFound"), feedback: t("exercise.standInFront"), warning: "" };
      }

      const pose = landmarks[0];

      if (!currentExercise || typeof currentExercise.analyze !== "function") {
        return { message: t("exercise.analysisUnavailable"), feedback: "", warning: "" };
      }

      const rawResult = currentExercise.analyze({
        pose,
        stageRef,
        lastRepTimeRef,
        setMainAngle,
        setExerciseStage,
        setReps,
      });

      return normalizeAnalyzeResult(rawResult);
    },
    [currentExercise, t],
  );

  const {
    videoRef,
    canvasRef,
    isCameraOn,
    cameraError,
    status,
    tip,
    feedback,
    warning,
    isModelReady,
    mainAngle,
    reps,
    exerciseStage,
    setTip,
    setFeedback,
    setWarning,
    startCamera,
    stopCamera,
    resetPoseState,
  } = usePoseDetection({
    analyzePose,
    cameraErrorText: t("exercise.cameraError"),
  });

  const totalExercises = editableSteps.length;
  const totalTargetReps = editableSteps.reduce(
    (sum, item) => sum + (Number(item.reps) || 0),
    0,
  );
  const completedTargetReps = editableSteps
    .slice(0, currentExerciseIndex)
    .reduce((sum, item) => sum + (Number(item.reps) || 0), 0);
  const totalCompletedReps = completedTargetReps + reps;

  // Формуємо список виконаних вправ для збереження підсумку заняття
  const completedExercises = useMemo(
    () =>
      editableSteps
        .map((step, index) => {
          let completedReps = 0;

          if (index < currentExerciseIndex) {
            completedReps = Number(step.reps) || 0;
          } else if (index === currentExerciseIndex) {
            completedReps = Math.min(reps, Number(step.reps) || 0);
          }

          return {
            exerciseId: step.exerciseId,
            exerciseName: getExerciseName(
              rehabExercises.find((item) => item.id === step.exerciseId),
            ),
            targetReps: Number(step.reps) || 0,
            completedReps,
          };
        })
        .filter((item) => item.completedReps > 0),
    [editableSteps, currentExerciseIndex, reps, getExerciseName],
  );
  const canSaveWorkoutResult = Boolean(
    user
      && isWorkoutCompleted
      && !isWorkoutResultSaved
      && (totalCompletedReps > 0 || completedExercises.some((item) => Number(item.completedReps) > 0)),
  );

  // Скидаємо стан аналізу, коли стартуємо/перемикаємо вправу
  const resetCurrentExerciseState = useCallback(() => {
    resetPoseState();
    setTip(t("exercise.standInFront"));
  }, [resetPoseState, setTip, t]);

  const finishWorkout = useCallback(() => {
    setIsWorkoutCompleted(true);
    setIsWorkoutStarted(false);
    setTip(t("workout.sessionCompleted"));
    setFeedback(t("workout.allExercisesDone"));
    setWarning("");
  }, [setFeedback, setTip, setWarning, t]);

  const goToNextExercise = useCallback(() => {
    const isLastExercise = currentExerciseIndex >= editableSteps.length - 1;

    if (isLastExercise) {
      finishWorkout();
      return;
    }

    setCurrentExerciseIndex((prev) => prev + 1);
    resetCurrentExerciseState();
  }, [
    currentExerciseIndex,
    editableSteps.length,
    finishWorkout,
    resetCurrentExerciseState,
  ]);

  // Даємо змогу змінювати повторення до старту тренування
  const updateStepReps = (index, value) => {
    setEditableSteps((prev) =>
      prev.map((step, stepIndex) =>
        stepIndex === index
          ? { ...step, reps: Math.max(1, Number(value) || 1) }
          : step,
      ),
    );
  };

  const decreaseStepReps = (index) => {
    setEditableSteps((prev) =>
      prev.map((step, stepIndex) =>
        stepIndex === index
          ? { ...step, reps: Math.max(1, Number(step.reps) - 1) }
          : step,
      ),
    );
  };

  const increaseStepReps = (index) => {
    setEditableSteps((prev) =>
      prev.map((step, stepIndex) =>
        stepIndex === index
          ? { ...step, reps: Math.max(1, Number(step.reps) + 1) }
          : step,
      ),
    );
  };


  const handleStartWorkout = () => {
    // Нове заняття: скидаємо блок переходу між вправами
    isChangingExerciseRef.current = false;
    if (changeExerciseTimeoutRef.current) {
      clearTimeout(changeExerciseTimeoutRef.current);
      changeExerciseTimeoutRef.current = null;
    }

    setSeconds(0);
    setCurrentExerciseIndex(0);
    setIsWorkoutStarted(true);
    setIsWorkoutCompleted(false);
    setIsWorkoutResultSaved(false);
    setSaveState("idle");
    resetCurrentExerciseState();
  };

  const handleStopWorkout = () => {
    isChangingExerciseRef.current = false;
    if (changeExerciseTimeoutRef.current) {
      clearTimeout(changeExerciseTimeoutRef.current);
      changeExerciseTimeoutRef.current = null;
    }
    setIsWorkoutStarted(false);
    setIsWorkoutCompleted(true);
  };

  const handleSaveWorkoutResult = async () => {
    if (!user || !canSaveWorkoutResult || isSavingResult) return;

    setIsSavingResult(true);
    setSaveState("idle");

    try {
      // Зберігаємо результат заняття у Firestore тільки після кліку по кнопці
      const payload = {
        userId: user.uid,
        userEmail: user.email || "",
        workoutId: workout.id || slug,
        workoutName: i18n.language === "en" ? workout.titleEn || workout.title : workout.title,
        seconds: Number(seconds) || 0,
        totalTargetReps: Number(totalTargetReps) || 0,
        totalCompletedReps: Number(totalCompletedReps) || 0,
        completedExercises,
        source: "readyWorkout",
      };
      await saveWorkoutResult(payload);

      // Обробка успішного збереження результату
      setIsWorkoutResultSaved(true);
      setSaveState("success");
    } catch (error) {
      console.error("Failed to save workout result:", error);
      // Обробка помилки збереження результату
      setSaveState("error");
    } finally {
      setIsSavingResult(false);
    }
  };

  const guidanceText = getExerciseGuidance({
    exerciseId: currentExercise?.id,
    exerciseName: getExerciseName(currentExercise),
    stage: exerciseStage,
    feedback,
    warning,
    reps,
    targetReps: Number(currentStep?.reps) || 0,
    language: i18n.language,
    t,
  });


  const stableFeedback = useStableValue(feedback, 400);
  const stableWarning = useStableValue(warning, 700);
  const stableGuidance = useStableValue(guidanceText, 400);

  const handleStartCamera = async () => {
    await startCamera();
  };

  const handleStopCamera = () => {
    stopCamera();
    resetCurrentExerciseState();
  };

  const handleFullscreen = async () => {
    if (!cameraSectionRef.current) return;

    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else {
        await cameraSectionRef.current.requestFullscreen();
      }
    } catch (error) {
      console.error("Помилка fullscreen:", error);
    }
  };

  useEffect(() => {
    let interval = null;

    if (isWorkoutStarted && !isWorkoutCompleted) {
      interval = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    }

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isWorkoutStarted, isWorkoutCompleted]);

  useEffect(() => {
    if (!isWorkoutStarted) return;
    if (isWorkoutCompleted) return;
    if (!currentStep) return;
    if (reps < Number(currentStep.reps)) return;
    if (isChangingExerciseRef.current) return;

    // Фіксуємо, що перехід уже запущено, щоб не скидався через часті оновлення з камери
    isChangingExerciseRef.current = true;
    changeExerciseTimeoutRef.current = setTimeout(() => {
      goToNextExercise();
      isChangingExerciseRef.current = false;
      changeExerciseTimeoutRef.current = null;
    }, 1200);

    return undefined;
  }, [
    reps,
    currentStep,
    isWorkoutStarted,
    isWorkoutCompleted,
    goToNextExercise,
  ]);

  useEffect(() => {
    return () => {
      if (changeExerciseTimeoutRef.current) {
        clearTimeout(changeExerciseTimeoutRef.current);
      }
    };
  }, []);

  if (!workout) {
    return (
      <>
        <Header />
        <main className="exercise-page">
          <div className="container">
            <div className="exercise-not-found">
              <h1>{t("common.workoutNotFound")}</h1>
              <Link to="/dashboard" className="btn btn--primary">
                {t("common.backToDashboard")}
              </Link>
            </div>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <Header />

      <main className="exercise-page">
        <div className="container">
          <div className="exercise-top">
            <Link
              to="/dashboard"
              className="back-button"
            >
              ← {t("exercise.back")}
            </Link>
          </div>

          <section className="exercise-main-card">
            <p className="page-badge">{t("workout.readySession")}</p>

            <h1>{i18n.language === "en" ? workout.titleEn || workout.title : workout.title}</h1>

            <p className="exercise-description">{i18n.language === "en" ? workout.descriptionEn || workout.description : workout.description}</p>

            <p className="exercise-reps">{t("workout.sessionTime")}: {formatTime(seconds)}</p>

            <div className="exercise-status-box workout-status-grid session-info-grid">
              <div className="workout-status-group session-info-section">
                <h3 className="workout-status-group-title session-info-section-title">{t("workout.progressTitle")}</h3>
                <p className="info-row session-info-row">
                  <span className="info-row__label session-info-label">{t("exercise.exerciseLabel")}:</span>
                  <span className="info-row__value session-info-value">{getExerciseName(currentExercise)}</span>
                </p>
                <p className="info-row session-info-row">
                  <span className="info-row__label session-info-label">{t("workout.step")}:</span>
                  <span className="info-row__value session-info-value">{currentExerciseIndex + 1} / {totalExercises}</span>
                </p>
                <p className="info-row session-info-row">
                  <span className="info-row__label session-info-label">{t("workout.targetReps")}:</span>
                  <span className="info-row__value session-info-value">{currentStep?.reps || 0}</span>
                </p>
                <p className="info-row session-info-row">
                  <span className="info-row__label session-info-label">{t("workout.completedReps")}:</span>
                  <span className="info-row__value session-info-value">{reps}</span>
                </p>
                <p className="info-row session-info-row">
                  <span className="info-row__label session-info-label">{t("workout.totalVolume")}:</span>
                  <span className="info-row__value session-info-value">{completedTargetReps + reps} / {totalTargetReps}</span>
                </p>
                <p className="info-row session-info-row">
                  <span className="info-row__label session-info-label">{t("workout.sessionStatus")}:</span>
                  <span className="info-row__value session-info-value">{isWorkoutCompleted
                    ? t("workout.statusCompleted")
                    : isWorkoutStarted
                      ? t("workout.statusActive")
                      : t("workout.statusReady")}</span>
                </p>
              </div>

              <div className="workout-status-group session-info-section">
                <h3 className="workout-status-group-title session-info-section-title">{t("workout.aiAnalysisTitle")}</h3>
                <p className="info-row session-info-row">
                  <span className="info-row__label session-info-label">{t("exercise.aiStatus")}:</span>
                  <span className="info-row__value session-info-value">{t(`status.${status}`, { defaultValue: status })}</span>
                </p>
                <p className="info-row session-info-row">
                  <span className="info-row__label session-info-label">{t("exercise.model")}:</span>
                  <span className="info-row__value session-info-value">{isModelReady ? t("exercise.modelReady") : t("exercise.modelLoading")}</span>
                </p>
                <p className="info-row session-info-row">
                  <span className="info-row__label session-info-label">{t("exercise.mainAngle")}:</span>
                  <span className="info-row__value session-info-value">{mainAngle}°</span>
                </p>
                <p className="info-row session-info-row">
                  <span className="info-row__label session-info-label">{t("exercise.exerciseStage")}:</span>
                  <span className="info-row__value session-info-value">{t(`status.${exerciseStage}`, { defaultValue: exerciseStage })}</span>
                </p>
              </div>
            </div>

            {!isWorkoutCompleted ? (
              <div className="exercise-actions session-action-row">
              {!isWorkoutStarted && !isWorkoutCompleted ? (
                <button
                  type="button"
                  className="btn btn--primary"
                  onClick={handleStartWorkout}
                >
                  {t("workout.startSession")}
                </button>
              ) : null}

              {isWorkoutStarted ? (
                <>
                  {currentExerciseIndex < totalExercises - 1 ? (
                    <button
                      type="button"
                      className="btn btn--secondary"
                      onClick={goToNextExercise}
                    >
                      {t("workout.nextExercise")}
                    </button>
                  ) : null}
                  <button
                    type="button"
                    className="btn btn--secondary"
                    onClick={handleStopWorkout}
                  >
                    {t("workout.finishWorkout")}
                  </button>
                </>
              ) : null}
              </div>
            ) : (
              <div className="session-result-card">
                <h3 className="session-result-title">{t("workout.workoutCompleted")}</h3>
                <div className="session-result-actions">
                  <button
                    type="button"
                    className="btn btn--primary"
                    onClick={handleSaveWorkoutResult}
                    disabled={!canSaveWorkoutResult || isSavingResult}
                  >
                    {t("workout.saveResult")}
                  </button>
                  <Link to="/dashboard" className="btn btn--secondary">
                    {t("workout.backToDashboard")}
                  </Link>
                </div>
                <div className={`session-result-hint ${
                  saveState === "success"
                    ? "session-result-hint--success"
                    : saveState === "error"
                      ? "session-result-hint--error"
                      : "session-result-hint--warning"
                }`}>
                  {saveState === "success"
                    ? t("workout.resultSaved")
                    : saveState === "error"
                      ? t("workout.saveResultError")
                      : canSaveWorkoutResult
                        ? t("workout.saveResultHint")
                        : t("workout.saveRequiresReps")}
                </div>
              </div>
            )}
          </section>

          <section className="exercise-main-card">
            <p className="exercise-label">{t("workout.playlist")}</p>

            <div className="dashboard-grid">
              {editableSteps.map((step, index) => {
                const stepExercise = rehabExercises.find(
                  (item) => item.id === step.exerciseId,
                );

                const isActive = index === currentExerciseIndex;
                const isDone = index < currentExerciseIndex;

                return (
                  <div
                    key={`${step.exerciseId}-${index}`}
                    className={`dashboard-card workout-playlist-card ${
                      isActive ? "dashboard-card--active workout-playlist-card--active" : ""
                    } ${isDone ? "workout-playlist-card--done" : ""}`}
                  >
                    <h3>{getExerciseName(stepExercise)}</h3>

                    <p>{getExerciseDescription(stepExercise)}</p>

                    <p className="workout-step-status-row">
                      <span className="workout-step-status-label">{t("workout.status")}:</span>{" "}
                      <span className="workout-status-badge meta-badge">
                      {isDone
                        ? t("workout.statusDone")
                        : isActive
                          ? t("workout.statusCurrent")
                          : t("workout.statusWaiting")}
                      </span>
                    </p>

                    <div className="workout-reps-control">
                      <button
                        type="button"
                        className="btn btn--secondary workout-reps-btn"
                        onClick={() => decreaseStepReps(index)}
                        disabled={isWorkoutStarted}
                      >
                        -
                      </button>

                      <input
                        type="number"
                        min="1"
                        value={step.reps}
                        onChange={(e) => updateStepReps(index, e.target.value)}
                        disabled={isWorkoutStarted}
                        className="workout-reps-input"
                      />

                      <button
                        type="button"
                        className="btn btn--secondary workout-reps-btn"
                        onClick={() => increaseStepReps(index)}
                        disabled={isWorkoutStarted}
                      >
                        +
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <section className="exercise-camera-section" ref={cameraSectionRef}>
            <div className="exercise-camera-header">
              <h2>{t("exercise.cameraTitle")}</h2>

              <button
                type="button"
                className="btn btn--secondary"
                onClick={handleFullscreen}
              >
                {t("exercise.fullscreen")}
              </button>
            </div>

            <div className="exercise-camera-large">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`exercise-video ${
                  !isCameraOn ? "exercise-video--hidden" : ""
                }`}
              />

              <canvas
                ref={canvasRef}
                className={`exercise-canvas ${
                  !isCameraOn ? "exercise-video--hidden" : ""
                }`}
              />

              {!isCameraOn && (
                <div className="exercise-camera-placeholder">
                  <p>{t("exercise.cameraOff")}</p>
                </div>
              )}

              <div className="exercise-overlay exercise-overlay--top">
                <div className="exercise-overlay-status">
                  <span
                    className={`exercise-overlay-dot ${
                      isCameraOn ? "exercise-overlay-dot--active" : ""
                    }`}
                  ></span>

                  <span>
                    {isCameraOn
                      ? t("exercise.overlayCameraOn")
                      : t("exercise.overlayCameraOff")}
                  </span>
                </div>

                <div className="exercise-overlay-message">
                  {isWorkoutCompleted
                    ? t("workout.sessionCompleted")
                    : isWorkoutStarted
                      ? `${t("workout.currentlyPerforming")}: ${getExerciseName(currentExercise)}`
                      : t("workout.readyToStart")}
                </div>
              </div>

              <div className="exercise-overlay exercise-overlay--bottom">
                <div className="exercise-hint-box">
                  <p>{tip || t("exercise.noFeedback")}</p>

                  <small className="exercise-ai-status">
                    {localizeMotionText(stableFeedback, i18n.language) ||
                      (isModelReady ? t("common.aiReady") : t("common.aiLoading"))}
                  </small>

                </div>
              </div>
            </div>

            {cameraError && (
              <div className="exercise-camera-error">
                <p>{cameraError}</p>
                <p>{t("exercise.cameraPermission")}</p>
              </div>
            )}

            <div className="exercise-actions exercise-actions--camera">
              {!isCameraOn ? (
                <button
                  type="button"
                  className="btn btn--primary"
                  onClick={handleStartCamera}
                  disabled={!isModelReady}
                >
                  {t("exercise.cameraStart")}
                </button>
              ) : (
                <button
                  type="button"
                  className="btn btn--secondary"
                  onClick={handleStopCamera}
                >
                  {t("exercise.cameraStop")}
                </button>
              )}
            </div>

            <div className="camera-status-overlay">
              <p className="camera-status-overlay__title">{getExerciseName(currentExercise)}</p>
              <p className="camera-status-overlay__meta">
                {t("exercise.stepProgress", { current: Math.min(currentExerciseIndex + 1, totalExercises), total: totalExercises })}
                {" · "}
                {t("exercise.completedProgress", { completed: reps, target: currentStep?.reps || 0 })}
              </p>
              <p className="camera-status-overlay__hint">{stableGuidance || t("exercise.cameraStatusDefault")}</p>
            </div>

            {stableWarning ? (
              <div className="camera-warning-box">
                <p>{t("exercise.warningPrefix", { message: localizeMotionText(stableWarning, i18n.language) })}</p>
              </div>
            ) : null}
          </section>
        </div>
      </main>
    </>
  );
}

function WorkoutSessionPage() {
  const { slug } = useParams();

  return <WorkoutSessionPageContent key={slug} slug={slug} />;
}

export default WorkoutSessionPage;