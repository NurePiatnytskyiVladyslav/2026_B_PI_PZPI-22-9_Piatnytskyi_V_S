// ---------------------------------
// *Назва файлу: ExercisePage.jsx*
// *Опис: Сторінка виконання одиночної реабілітаційної вправи*
// *Що робить: Запускає камеру, аналізує рух через MediaPipe, рахує повторення та дозволяє зберегти результат*
// ---------------------------------
import { useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import Header from "../components/Header";
import rehabExercises from "../exercises/index.js";
import usePoseDetection from "../hooks/usePoseDetection";
import { useAuth } from "../context/useAuth";
import { saveExerciseResult } from "../services/exerciseResultsService";
import { localizeMotionText } from "../utils/localizeMotionText";
import { getExerciseGuidance } from "../utils/getExerciseGuidance";
import useStableValue from "../hooks/useStableValue";

function formatTime(totalSeconds) {
  const mins = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const secs = String(totalSeconds % 60).padStart(2, "0");
  return `${mins}:${secs}`;
}

function normalizeAnalyzeResult(result) {
  if (typeof result === "string") {
    return {
      message: result,
      feedback: "",
      warning: "",
    };
  }

  if (result && typeof result === "object") {
    return {
      message: result.message || "",
      feedback: result.feedback || "",
      warning: result.warning || "",
    };
  }

  return {
    message: "no analysis yet",
    feedback: "",
    warning: "",
  };
}

function ExercisePageContent({ slug }) {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();

  const exercise = rehabExercises.find((item) => item.id === slug);
  const getExerciseName = (item) =>
    i18n.language === "en" ? item.nameEn || item.name : item.name;
  const [isStarted, setIsStarted] = useState(false);
  const [isExerciseCompleted, setIsExerciseCompleted] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [saveState, setSaveState] = useState("idle");

  const cameraSectionRef = useRef(null);

  // Функція аналізу конкретної вправи. Передаємо її в hook.
  const analyzePose = ({ landmarks, stageRef, lastRepTimeRef, setMainAngle, setExerciseStage, setReps }) => {
    if (!landmarks || landmarks.length === 0) {
      setMainAngle(0);
      setExerciseStage("start");
      stageRef.current = "start";

      return {
        message: t("exercise.humanNotFound"),
        feedback: t("exercise.standInFront"),
        warning: "",
      };
    }

    const pose = landmarks[0];

    if (!exercise || typeof exercise.analyze !== "function") {
      return {
        message: t("exercise.analysisUnavailable"),
        feedback: "",
        warning: "",
      };
    }

    const rawResult = exercise.analyze({
      pose,
      stageRef,
      lastRepTimeRef,
      setMainAngle,
      setExerciseStage,
      setReps,
    });

    return normalizeAnalyzeResult(rawResult);
  };

  const {
    videoRef,
    canvasRef,
    isCameraOn,
    cameraError,
    status,
    tip,
    feedback,
    warning,
    isModelReady,
    mainAngle,
    reps,
    exerciseStage,
    startCamera,
    stopCamera,
    resetPoseState,
  } = usePoseDetection({
    analyzePose,
    cameraErrorText: t("exercise.cameraError"),
  });

  const handleStartExercise = () => {
    setSeconds(0);
    setIsStarted(true);
    setIsExerciseCompleted(false);
    setSaveState("idle");
    resetPoseState();
  };

  const handleStopExercise = () => {
    setIsStarted(false);
    setIsExerciseCompleted(true);
  };

  const canSaveResult = Boolean(user) && isExerciseCompleted && reps > 0 && saveState !== "success";
  const exerciseTargetReps = Number(exercise?.targetReps || exercise?.reps || 0);


  const handleSaveResult = async () => {
    if (!canSaveResult || !exercise) return;

    try {
      await saveExerciseResult({
        userId: user.uid,
        userEmail: user.email || "",
        exerciseId: exercise.id,
        exerciseName: exercise.name,
        reps,
        seconds,
        mainAngle,
        feedback,
        warning,
      });
      // Обробка успішного збереження
      setSaveState("success");
    } catch (error) {
      console.error("Помилка збереження результату:", error);
      setSaveState("error");
    }
  };

  const guidanceText = getExerciseGuidance({
    exerciseId: exercise?.id,
    exerciseName: getExerciseName(exercise),
    stage: exerciseStage,
    feedback,
    warning,
    reps,
    targetReps: exerciseTargetReps,
    language: i18n.language,
    t,
  });


  const stableFeedback = useStableValue(feedback, 400);
  const stableWarning = useStableValue(warning, 700);
  const stableGuidance = useStableValue(guidanceText, 400);

  const handleStartCamera = async () => {
    await startCamera();
  };

  const handleStopCamera = () => {
    stopCamera();
    resetPoseState();
  };

  const handleFullscreen = async () => {
    if (!cameraSectionRef.current) return;

    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else {
        await cameraSectionRef.current.requestFullscreen();
      }
    } catch (error) {
      console.error("Помилка fullscreen:", error);
    }
  };

  useEffect(() => {
    let interval = null;

    if (isStarted) {
      interval = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    }

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isStarted]);


  if (!exercise) {
    return (
      <>
        <Header />
        <main className="exercise-page">
          <div className="container">
            <div className="exercise-not-found">
              <h1>{t("common.exerciseNotFound")}</h1>
              <Link to="/dashboard" className="btn btn--primary">
                {t("common.backToDashboard")}
              </Link>
            </div>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <Header />

      <main className="exercise-page">
        <div className="container">
          <div className="exercise-top">
            <Link
              to="/dashboard"
              className="back-button"
            >
              ← {t("exercise.back")}
            </Link>
          </div>

          <section className="exercise-main-card">
            <p className="page-badge">{t("exercise.label")}</p>

            <h1>{getExerciseName(exercise)}</h1>

            <p className="exercise-reps">
              {t("exercise.timerLabel")}: {formatTime(seconds)}
            </p>

            <p className="exercise-description">
              {t("exercise.tipText")}
            </p>

            <div className="exercise-status-box exercise-status-grid">
              <div className="exercise-status-section">
                <h3 className="workout-status-group-title">{t("exercise.progressTitle")}</h3>
                <p className="info-row">
                  <span className="info-row__label">{t("workout.status")}:</span>
                  <span className="info-row__value">
                    {isStarted ? t("exercise.statusActive") : t("exercise.statusReady")}
                  </span>
                </p>
                <p className="info-row">
                  <span className="info-row__label">{t("exercise.repetitions")}:</span>
                  <span className="info-row__value">{reps}</span>
                </p>
              </div>

              <div className="exercise-status-section">
                <h3 className="workout-status-group-title">{t("exercise.aiAnalysisTitle")}</h3>
                <p className="info-row">
                  <span className="info-row__label">{t("exercise.aiStatus")}:</span>
                  <span className="info-row__value">{t(`status.${status}`, { defaultValue: status })}</span>
                </p>
                <p className="info-row">
                  <span className="info-row__label">{t("exercise.model")}:</span>
                  <span className="info-row__value">{isModelReady ? t("exercise.modelReady") : t("exercise.modelLoading")}</span>
                </p>
                <p className="info-row">
                  <span className="info-row__label">{t("exercise.mainAngle")}:</span>
                  <span className="info-row__value">{mainAngle}°</span>
                </p>
                <p className="info-row">
                  <span className="info-row__label">{t("exercise.exerciseStage")}:</span>
                  <span className="info-row__value">{t(`status.${exerciseStage}`, { defaultValue: exerciseStage })}</span>
                </p>
              </div>
            </div>

            {!isExerciseCompleted ? (
              <div className="exercise-actions session-action-row">
                {!isStarted ? (
                  <button
                    type="button"
                    className="btn btn--primary"
                    onClick={handleStartExercise}
                  >
                    {t("exercise.start")}
                  </button>
                ) : (
                  <button
                    type="button"
                    className="btn btn--secondary"
                    onClick={handleStopExercise}
                  >
                    {t("exercise.finishExercise")}
                  </button>
                )}
              </div>
            ) : (
              <div className="session-result-card">
                <h3 className="session-result-title">{t("exercise.exerciseCompleted")}</h3>
                <div className="session-result-actions">
                  <button
                    type="button"
                    className="btn btn--primary"
                    onClick={handleSaveResult}
                    disabled={!canSaveResult}
                  >
                    {t("exercise.saveResult")}
                  </button>
                  <Link to="/dashboard" className="btn btn--secondary">
                    {t("exercise.backToDashboard")}
                  </Link>
                </div>
                <div className={`session-result-hint ${
                  saveState === "success"
                    ? "session-result-hint--success"
                    : saveState === "error"
                      ? "session-result-hint--error"
                      : !canSaveResult
                        ? "session-result-hint--warning"
                        : "session-result-hint--warning"
                }`}>
                  {saveState === "success"
                    ? t("exercise.resultSaved")
                    : saveState === "error"
                      ? t("exercise.saveResultError")
                      : reps > 0
                        ? t("exercise.saveResultHint")
                        : t("exercise.saveRequiresReps")}
                </div>
              </div>
            )}
          </section>

          <section className="exercise-camera-section" ref={cameraSectionRef}>
            <div className="exercise-camera-header">
              <h2>{t("exercise.cameraTitle")}</h2>

              <button
                type="button"
                className="btn btn--secondary"
                onClick={handleFullscreen}
              >
                {t("exercise.fullscreen")}
              </button>
            </div>

            <div className="exercise-camera-large">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`exercise-video ${
                  !isCameraOn ? "exercise-video--hidden" : ""
                }`}
              />

              <canvas
                ref={canvasRef}
                className={`exercise-canvas ${
                  !isCameraOn ? "exercise-video--hidden" : ""
                }`}
              />

              {!isCameraOn && (
                <div className="exercise-camera-placeholder">
                  <p>{t("exercise.cameraOff")}</p>
                </div>
              )}

              <div className="exercise-overlay exercise-overlay--top">
                <div className="exercise-overlay-status">
                  <span
                    className={`exercise-overlay-dot ${
                      isCameraOn ? "exercise-overlay-dot--active" : ""
                    }`}
                  ></span>

                  <span>
                    {isCameraOn
                      ? t("exercise.overlayCameraOn")
                      : t("exercise.overlayCameraOff")}
                  </span>
                </div>

                <div className="exercise-overlay-message">
                  {isStarted
                    ? t("exercise.overlayActive")
                    : t("exercise.overlayReady")}
                </div>
              </div>

              <div className="exercise-overlay exercise-overlay--bottom">
                <div className="exercise-hint-box">
                  <p>{tip || t("exercise.noFeedback")}</p>

                  <small className="exercise-ai-status">
                    {localizeMotionText(stableFeedback, i18n.language) ||
                      (isModelReady ? t("common.aiReady") : t("common.aiLoading"))}
                  </small>

                </div>
              </div>
            </div>

            {cameraError && (
              <div className="exercise-camera-error">
                <p>{cameraError}</p>
                <p>{t("exercise.cameraPermission")}</p>
              </div>
            )}

            <div className="exercise-actions">
              {!isCameraOn ? (
                <button
                  type="button"
                  className="btn btn--primary"
                  onClick={handleStartCamera}
                  disabled={!isModelReady}
                >
                  {t("exercise.cameraStart")}
                </button>
              ) : (
                <button
                  type="button"
                  className="btn btn--secondary"
                  onClick={handleStopCamera}
                >
                  {t("exercise.cameraStop")}
                </button>
              )}
            </div>


            <div className="camera-status-overlay">
              <p className="camera-status-overlay__title">{getExerciseName(exercise)}</p>
              <p className="camera-status-overlay__meta">{exerciseTargetReps > 0
                ? t("exercise.completedProgress", { completed: reps, target: exerciseTargetReps })
                : t("exercise.repsProgress", { completed: reps })}</p>
              <p className="camera-status-overlay__hint">{stableGuidance || t("exercise.cameraStatusDefault")}</p>
            </div>

            {stableWarning ? (
              <div className="camera-warning-box">
                <p>{t("exercise.warningPrefix", { message: localizeMotionText(stableWarning, i18n.language) })}</p>
              </div>
            ) : null}
          </section>
        </div>
      </main>
    </>
  );
}

function ExercisePage() {
  const { slug } = useParams();

  return <ExercisePageContent key={slug} slug={slug} />;
}

export default ExercisePage;