// ---------------------------------
// *Назва файлу: DoctorDashboardPage.jsx*
// *Опис: Сторінка кабінету лікаря*
// *Що робить: Відображає список пацієнтів, пошук і фільтрацію за проблемною зоною*
// ---------------------------------
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import Header from "../components/Header";
import { useAuth } from "../context/useAuth";
import { getPatients } from "../services/userService";

const getProblemAreaLabel = (value, t) => {
  if (!value) return t("profile.problemAreaNotSpecified");
  return t(`problemAreas.${value}`);
};

function DoctorDashboardPage() {
  const { t } = useTranslation();
  const { isDoctor } = useAuth();
  const [patients, setPatients] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedProblemArea, setSelectedProblemArea] = useState("all");

  useEffect(() => {
    if (!isDoctor) return;
    getPatients().then(setPatients).catch(() => setPatients([]));
  }, [isDoctor]);

  const filteredPatients = patients.filter((patient) => {
    const normalizedSearch = searchTerm.trim().toLowerCase();
    const patientName = patient.displayName?.toLowerCase() || "";
    const patientEmail = patient.email?.toLowerCase() || "";

    const matchesSearch = !normalizedSearch
      || patientName.includes(normalizedSearch)
      || patientEmail.includes(normalizedSearch);

    const patientProblemArea = patient.problemArea?.trim() || "";
    const matchesProblemArea = selectedProblemArea === "all"
      ? true
      : selectedProblemArea === "notSpecified"
        ? !patientProblemArea
        : patientProblemArea === selectedProblemArea;

    return matchesSearch && matchesProblemArea;
  });

  return (
    <div>
      <Header />
      <main className="container doctor-dashboard-page">
        <h1 className="doctor-dashboard-title">{t("doctor.title")}</h1>

        {!isDoctor ? (
          <p>{t("doctor.noAccess")}</p>
        ) : (
          <>
            <p className="doctor-dashboard-description">{t("doctor.description")}</p>
            <h2 className="doctor-dashboard-section-title">{t("doctor.patientsList")}</h2>
            <div className="doctor-search">
              <div className="doctor-filters">
                <input
                  type="text"
                  className="doctor-search-input"
                  value={searchTerm}
                  onChange={(event) => setSearchTerm(event.target.value)}
                  placeholder={t("doctor.searchPlaceholder")}
                />
                <select
                  className="doctor-filter-select"
                  value={selectedProblemArea}
                  onChange={(event) => setSelectedProblemArea(event.target.value)}
                  aria-label={t("doctor.problemAreaFilter")}
                >
                  <option value="all">{t("doctor.allProblemAreas")}</option>
                  <option value="arm">{t("problemAreas.arm")}</option>
                  <option value="leg">{t("problemAreas.leg")}</option>
                  <option value="neck">{t("problemAreas.neck")}</option>
                  <option value="back">{t("problemAreas.back")}</option>
                  <option value="shoulder">{t("problemAreas.shoulder")}</option>
                  <option value="knee">{t("problemAreas.knee")}</option>
                  <option value="other">{t("problemAreas.other")}</option>
                  <option value="notSpecified">{t("doctor.notSpecified")}</option>
                </select>
              </div>
              <p className="doctor-filter-count">
                {t("doctor.patientsFound", { count: filteredPatients.length })}
              </p>
            </div>

            {filteredPatients.length === 0 ? (
              <p className="doctor-dashboard-empty">{t("doctor.noSearchResults")}</p>
            ) : (
              <div className="doctor-patient-cards-grid">
                {filteredPatients.map((patient) => (
                  <div key={patient.uid || patient.id} className="doctor-patient-result-card doctor-patient-card">
                    <p><strong>{patient.displayName || t("doctor.unnamedPatient")}</strong></p>
                    <p>{patient.email || "-"}</p>
                    <div className="doctor-patient-problem">
                      <p><strong>{t("profile.problemArea")}:</strong> {getProblemAreaLabel(patient.problemArea, t)}</p>
                      {patient.problemAreaNote ? <p className="doctor-patient-problem-note"><strong>{t("profile.problemAreaNote")}:</strong> {patient.problemAreaNote}</p> : null}
                    </div>
                    <Link className="btn btn--secondary" to={`/doctor/patient/${patient.uid || patient.id}`}>{t("doctor.viewProgress")}</Link>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}

export default DoctorDashboardPage;