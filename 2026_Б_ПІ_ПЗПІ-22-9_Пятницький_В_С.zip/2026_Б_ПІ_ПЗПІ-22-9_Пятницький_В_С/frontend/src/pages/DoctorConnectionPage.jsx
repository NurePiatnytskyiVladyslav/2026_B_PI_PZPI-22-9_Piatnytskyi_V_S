// ---------------------------------
// *Назва файлу: DoctorConnectionPage.jsx*
// *Опис: Сторінка зв’язку пацієнта з лікарем*
// *Що робить: Дозволяє переглядати та керувати підключенням пацієнта до лікаря*
// ---------------------------------
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import Header from "../components/Header";
import { useAuth } from "../context/useAuth";
import { updateUserProblemArea } from "../services/userService";
import { getAssignedPlanByPatientId } from "../services/assignedPlansService";

function DoctorConnectionPage() {
  const { t } = useTranslation();
  const { user, userProfile, refreshUserProfile } = useAuth();

  const [problemArea, setProblemArea] = useState("");
  const [problemAreaNote, setProblemAreaNote] = useState("");
  const [problemMessage, setProblemMessage] = useState("");
  const [problemError, setProblemError] = useState("");
  const [isSavingProblem, setIsSavingProblem] = useState(false);

  const [assignedPlan, setAssignedPlan] = useState(null);
  const [assignedPlanLoading, setAssignedPlanLoading] = useState(false);
  const [assignedPlanError, setAssignedPlanError] = useState("");

  const problemAreaOptions = ["arm", "leg", "neck", "back", "shoulder", "knee", "other"];

  useEffect(() => {
    setProblemArea(userProfile?.problemArea || "");
    setProblemAreaNote(userProfile?.problemAreaNote || "");
  }, [userProfile?.problemArea, userProfile?.problemAreaNote]);

  useEffect(() => {
    const loadAssignedPlan = async () => {
      if (!user?.uid) {
        setAssignedPlan(null);
        setAssignedPlanError("");
        return;
      }

      try {
        setAssignedPlanLoading(true);
        setAssignedPlanError("");
        const loadedAssignedPlan = await getAssignedPlanByPatientId(user.uid);
        setAssignedPlan(loadedAssignedPlan);
      } catch {
        setAssignedPlanError(t("plan.assignedPlanLoadError"));
      } finally {
        setAssignedPlanLoading(false);
      }
    };

    loadAssignedPlan();
  }, [t, user?.uid]);

  const handleSaveProblemArea = async () => {
    if (!user?.uid) return;

    try {
      setIsSavingProblem(true);
      setProblemMessage("");
      setProblemError("");

      await updateUserProblemArea(user.uid, {
        problemArea,
        problemAreaNote: problemAreaNote.trim(),
      });

      await refreshUserProfile(user.uid);
      setProblemMessage(t("profile.problemAreaSaved"));
    } catch {
      setProblemError(t("profile.problemAreaSaveError"));
    } finally {
      setIsSavingProblem(false);
    }
  };

  return (
    <>
      <Header />
      <main className="doctor-connection-page">
        <div className="container">
          <div className="page-top-actions">
            <Link to="/dashboard" className="exercise-back-link exercise-back-link--ui">
              ← {t("common.backToDashboard")}
            </Link>
          </div>

          <section className="plan-header">
            <h1>{t("doctorConnection.title")}</h1>
            <p>{t("doctorConnection.subtitle")}</p>
          </section>

          <div className="doctor-connection-grid">
            <section className="doctor-connection-card">
              <h2>{t("doctorConnection.problemTitle")}</h2>
              <div className="profile-problem-form">
                <div className="profile-problem-field">
                  <label htmlFor="problemAreaSelect">{t("profile.problemArea")}</label>
                  <select
                    id="problemAreaSelect"
                    value={problemArea}
                    onChange={(event) => setProblemArea(event.target.value)}
                  >
                    <option value="">{t("profile.problemAreaNotSpecified")}</option>
                    {problemAreaOptions.map((item) => (
                      <option key={item} value={item}>
                        {t(`problemAreas.${item}`)}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="profile-problem-field">
                  <label htmlFor="problemAreaNote">{t("profile.problemAreaNote")}</label>
                  <textarea
                    id="problemAreaNote"
                    value={problemAreaNote}
                    onChange={(event) => setProblemAreaNote(event.target.value)}
                    placeholder={t("profile.problemAreaPlaceholder")}
                    rows={3}
                  />
                </div>

                <button type="button" className="btn btn--primary" onClick={handleSaveProblemArea} disabled={isSavingProblem}>
                  {t("profile.saveProblemArea")}
                </button>
                <p className="doctor-visibility-note">{t("doctorConnection.visibleToDoctor")}</p>

                {problemMessage ? <p className="profile-problem-message">{problemMessage}</p> : null}
                {problemError ? <p className="profile-problem-message profile-problem-error">{problemError}</p> : null}
              </div>
            </section>

            <section className="doctor-connection-card doctor-connection-plan">
              <h2>{t("doctorConnection.assignedPlanTitle")}</h2>

              {assignedPlanLoading ? <p>{t("progress.loading")}</p> : null}
              {!assignedPlanLoading && assignedPlanError ? <p className="assigned-patient-plan-error">{assignedPlanError}</p> : null}

              {!assignedPlanLoading && !assignedPlanError && assignedPlan ? (
                <>
                  <h3>{assignedPlan.title}</h3>
                  {assignedPlan.description ? <p>{assignedPlan.description}</p> : null}
                  <div className="assigned-patient-exercise-list">
                    {(assignedPlan.exercises || []).map((exercise, index) => (
                      <article key={`${exercise.exerciseId || exercise.exerciseName || "exercise"}-${index}`} className="assigned-patient-exercise-item">
                        <h4>{exercise.exerciseName || exercise.exerciseId || t("common.notAvailable")}</h4>
                        <div className="assigned-patient-exercise-meta">
                          <p>{t("plan.targetReps")}: {exercise.targetReps ?? t("common.notAvailable")}</p>
                          {exercise.note ? <p>{t("plan.exerciseNote")}: {exercise.note}</p> : null}
                        </div>
                        {exercise.exerciseId ? <Link className="nav-register" to={`/exercise/${exercise.exerciseId}`}>{t("plan.startExercise")}</Link> : null}
                      </article>
                    ))}
                  </div>
                </>
              ) : null}

              {!assignedPlanLoading && !assignedPlanError && !assignedPlan ? <p className="doctor-connection-empty">{t("doctorConnection.noAssignedPlan")}</p> : null}
            </section>
          </div>
        </div>
      </main>
    </>
  );
}

export default DoctorConnectionPage;