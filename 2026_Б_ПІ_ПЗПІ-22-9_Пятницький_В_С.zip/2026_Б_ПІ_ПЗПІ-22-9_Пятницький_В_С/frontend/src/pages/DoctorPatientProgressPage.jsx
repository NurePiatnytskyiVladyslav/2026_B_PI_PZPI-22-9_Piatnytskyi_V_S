// ---------------------------------
// *Назва файлу: DoctorPatientProgressPage.jsx*
// *Опис: Сторінка перегляду прогресу конкретного пацієнта лікарем*
// *Що робить: Показує профіль, результати пацієнта та дозволяє створювати або редагувати план від лікаря*
// ---------------------------------
import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import Header from "../components/Header";
import { useAuth } from "../context/useAuth";
import exercises from "../exercises";
import { getUserProfile } from "../services/userService";
import { getExerciseResultsByUserId } from "../services/exerciseResultsService";
import { getWorkoutResultsByUserId } from "../services/workoutResultsService";
import {
  createAssignedPlan,
  getAssignedPlanByPatientId,
  updateAssignedPlan,
} from "../services/assignedPlansService";
import { formatDate } from "../utils/formatDate";
import { localizeMotionText } from "../utils/localizeMotionText";

const getTime = (item) => (item.createdAt?.toMillis ? item.createdAt.toMillis() : 0);

const getProblemAreaLabel = (value, t) => {
  if (!value) return t("profile.problemAreaNotSpecified");
  return t(`problemAreas.${value}`);
};

const emptyExercise = {
  exerciseId: "",
  exerciseName: "",
  targetReps: 8,
  note: "",
};

function DoctorPatientProgressPage() {
  const { t, i18n } = useTranslation();
  const { patientId } = useParams();
  const { isDoctor, user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [patient, setPatient] = useState(null);
  const [exerciseResults, setExerciseResults] = useState([]);
  const [workoutResults, setWorkoutResults] = useState([]);
  const [assignedPlan, setAssignedPlan] = useState(null);
  const [isEditingPlan, setIsEditingPlan] = useState(false);
  const [planForm, setPlanForm] = useState({ title: "", description: "", exercises: [] });
  const [planMessage, setPlanMessage] = useState("");
  const [planError, setPlanError] = useState("");
  const [isSavingPlan, setIsSavingPlan] = useState(false);

  const exercisesOptions = useMemo(
    () =>
      exercises.map((exercise) => ({
        id: exercise.id,
        label: i18n.language === "en" && exercise.nameEn ? exercise.nameEn : exercise.name,
      })),
    [i18n.language],
  );

  const findExerciseById = (exerciseId) => exercises.find((exercise) => exercise.id === exerciseId);

  const getExerciseDisplayName = (exercise) => {
    const found = findExerciseById(exercise.exerciseId);
    if (found) {
      return i18n.language === "en" && found.nameEn ? found.nameEn : found.name;
    }
    return exercise.exerciseName || exercise.exerciseId || "-";
  };

  const fillPlanForm = (plan) => {
    if (!plan) {
      setPlanForm({
        title: t("doctor.patientPlan"),
        description: "",
        exercises: [{ ...emptyExercise }],
      });
      return;
    }

    setPlanForm({
      title: plan.title || "",
      description: plan.description || "",
      exercises: Array.isArray(plan.exercises) && plan.exercises.length > 0
        ? plan.exercises.map((item) => ({ ...emptyExercise, ...item }))
        : [{ ...emptyExercise }],
    });
  };

  useEffect(() => {
    if (!isDoctor) return;
    const load = async () => {
      const loadErrors = [];
      try {
        setLoading(true);
        setError("");

        try {
          const profile = await getUserProfile(patientId);
          setPatient(profile);
        } catch {
          loadErrors.push("Не вдалося завантажити профіль пацієнта");
          setPatient(null);
        }

        try {
          const exercisesData = await getExerciseResultsByUserId(patientId);
          setExerciseResults(exercisesData);
        } catch {
          loadErrors.push("Не вдалося завантажити результати вправ");
          setExerciseResults([]);
        }

        try {
          const workouts = await getWorkoutResultsByUserId(patientId);
          setWorkoutResults(workouts);
        } catch {
          loadErrors.push("Не вдалося завантажити результати занять");
          setWorkoutResults([]);
        }

        try {
          const plan = await getAssignedPlanByPatientId(patientId);
          setAssignedPlan(plan);
        } catch {
          loadErrors.push(t("doctor.planSaveError"));
          setAssignedPlan(null);
        }

        if (loadErrors.length > 0) {
          setError(loadErrors.join(". "));
        }
      } catch {
        setError(t("doctor.errorPatient"));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [isDoctor, patientId, t]);

  const stats = useMemo(() => {
    const totalRepsExercises = exerciseResults.reduce((sum, i) => sum + (i.reps || 0), 0);
    const totalRepsWorkouts = workoutResults.reduce((sum, i) => sum + (i.totalCompletedReps || 0), 0);
    const totalTime = [...exerciseResults, ...workoutResults].reduce((sum, i) => sum + (i.seconds || 0), 0);
    const last = [...exerciseResults, ...workoutResults].sort((a, b) => getTime(b) - getTime(a))[0];

    return {
      exerciseCount: exerciseResults.length,
      workoutCount: workoutResults.length,
      totalReps: totalRepsExercises + totalRepsWorkouts,
      totalTime,
      lastActivity: last ? formatDate(last.createdAt, i18n.language) : "-",
    };
  }, [exerciseResults, i18n.language, workoutResults]);

  const startEditingPlan = () => {
    setPlanMessage("");
    setPlanError("");
    fillPlanForm(assignedPlan);
    setIsEditingPlan(true);
  };

  const handleExerciseChange = (index, field, value) => {
    // Оновлення вправ у плані
    setPlanForm((prev) => {
      const updated = [...prev.exercises];
      const current = { ...updated[index] };
      if (field === "exerciseId") {
        const found = findExerciseById(value);
        current.exerciseId = value;
        current.exerciseName = found ? (i18n.language === "en" && found.nameEn ? found.nameEn : found.name) : "";
      } else if (field === "targetReps") {
        current.targetReps = Number(value);
      } else {
        current[field] = value;
      }
      updated[index] = current;
      return { ...prev, exercises: updated };
    });
  };

  const handleSavePlan = async () => {
    const isInvalid =
      !planForm.title.trim() ||
      planForm.exercises.length === 0 ||
      planForm.exercises.some((item) => !item.exerciseId || Number(item.targetReps) <= 0);

    if (isInvalid) {
      setPlanError(t("doctor.planValidationError"));
      setPlanMessage("");
      return;
    }

    try {
      setIsSavingPlan(true);
      setPlanError("");

      // Формування payload плану
      const payload = {
        title: planForm.title.trim(),
        description: planForm.description.trim(),
        exercises: planForm.exercises.map((item) => ({
          exerciseId: item.exerciseId,
          exerciseName: item.exerciseName,
          targetReps: Number(item.targetReps),
          note: item.note || "",
        })),
      };

      // Збереження плану
      if (assignedPlan?.id) {
        await updateAssignedPlan(assignedPlan.id, payload);
      } else {
        await createAssignedPlan({
          doctorId: user.uid,
          patientId,
          ...payload,
        });
      }

      const refreshedPlan = await getAssignedPlanByPatientId(patientId);
      setAssignedPlan(refreshedPlan);
      setPlanMessage(t("doctor.planSaved"));
      setIsEditingPlan(false);
    } catch {
      setPlanMessage("");
      setPlanError(t("doctor.planSaveError"));
    } finally {
      setIsSavingPlan(false);
    }
  };

  if (!isDoctor) return <p>{t("doctor.noAccess")}</p>;

  return (
    <div>
      <Header />
      <main className="container doctor-patient-page">
        <div className="doctor-patient-header">
          <h1>{t("doctor.patientProfile")}</h1>
          <Link to="/doctor">{t("doctor.backToDoctor")}</Link>
        </div>

        {loading && <p className="app-state app-state--loading">{t("common.loading")}</p>}
        {error && <p className="app-state app-state--error">{error || t("common.error")}</p>}

        {!loading && !error && (
          <>
            <section className="doctor-patient-profile">
              <p><strong>{t("doctor.patientProfile")}:</strong> {patient?.displayName || t("doctor.unnamedPatient")}</p>
              <p><strong>{t("doctor.patientEmail")}:</strong> {patient?.email || "-"}</p>
              <p><strong>{t("doctor.patientId")}:</strong> {patientId?.slice(0, 8)}...</p>
              <p><strong>{t("doctor.patientRole")}:</strong> {patient?.role || "patient"}</p>
              <div className="doctor-patient-problem">
                <p><strong>{t("profile.problemArea")}:</strong> {getProblemAreaLabel(patient?.problemArea, t)}</p>
                {patient?.problemAreaNote ? <p><strong>{t("profile.problemAreaNote")}:</strong> {patient.problemAreaNote}</p> : null}
              </div>
            </section>

            <section className="doctor-patient-results-section">
              <h2>{t("doctor.patientStats")}</h2>
              <div className="doctor-patient-stats-grid">
                <div className="doctor-patient-stat-card"><strong>{t("doctor.exerciseResultsCount")}:</strong> {stats.exerciseCount}</div>
                <div className="doctor-patient-stat-card"><strong>{t("doctor.workoutResultsCount")}:</strong> {stats.workoutCount}</div>
                <div className="doctor-patient-stat-card"><strong>{t("doctor.totalReps")}:</strong> {stats.totalReps}</div>
                <div className="doctor-patient-stat-card"><strong>{t("doctor.totalTime")}:</strong> {stats.totalTime}s</div>
                <div className="doctor-patient-stat-card"><strong>{t("doctor.lastActivity")}:</strong> {stats.lastActivity}</div>
              </div>
            </section>

            <section className="assigned-plan-section">
              <h2>{t("doctor.patientPlan")}</h2>
              {planMessage ? <p className="assigned-plan-message">{planMessage}</p> : null}
              {planError ? <p className="assigned-plan-error">{planError}</p> : null}

              {!isEditingPlan && (
                <div className="assigned-plan-card assigned-plan-card--view">
                  {assignedPlan ? (
                    <>
                      <div className="assigned-plan-actions">
                        <button type="button" className="btn btn--secondary" onClick={startEditingPlan}>
                          {t("doctor.editPlan")}
                        </button>
                      </div>
                      <h3>{assignedPlan.title}</h3>
                      <p>{assignedPlan.description || "-"}</p>
                      <ul className="assigned-plan-exercise-list">
                        {assignedPlan.exercises?.map((item, index) => (
                          <li key={`${item.exerciseId || index}-${index}`} className="assigned-plan-exercise-item">
                            <div>
                              <strong>{getExerciseDisplayName(item)}</strong>
                              <p>{t("doctor.targetReps")}: {item.targetReps}</p>
                              <p>{t("doctor.note")}: {item.note || "-"}</p>
                            </div>
                            
                          </li>
                        ))}
                      </ul>
                    </>
                  ) : (
                    <>
                      <p>{t("doctor.noAssignedPlan")}</p>
                      <button type="button" className="btn btn--primary" onClick={startEditingPlan}>
                        {t("doctor.createPlan")}
                      </button>
                    </>
                  )}
                </div>
              )}

              {isEditingPlan && (
                <div className="assigned-plan-card assigned-plan-card--edit assigned-plan-form">
                  <label>
                    {t("doctor.planTitle")}
                    <input
                      type="text"
                      value={planForm.title}
                      onChange={(e) => setPlanForm((prev) => ({ ...prev, title: e.target.value }))}
                    />
                  </label>

                  <label>
                    {t("doctor.planDescription")}
                    <textarea
                      value={planForm.description}
                      onChange={(e) => setPlanForm((prev) => ({ ...prev, description: e.target.value }))}
                    />
                  </label>

                  {planForm.exercises.map((item, index) => (
                    <div key={`plan-exercise-${index}`} className="assigned-plan-row">
                      <label>
                        {t("doctor.exercise")}
                        <select
                          value={item.exerciseId}
                          onChange={(e) => handleExerciseChange(index, "exerciseId", e.target.value)}
                        >
                          <option value="">-</option>
                          {exercisesOptions.map((option) => (
                            <option key={option.id} value={option.id}>{option.label}</option>
                          ))}
                        </select>
                      </label>
                      <label>
                        {t("doctor.targetReps")}
                        <input
                          type="number"
                          min={1}
                          value={item.targetReps}
                          onChange={(e) => handleExerciseChange(index, "targetReps", e.target.value)}
                        />
                      </label>
                      <label>
                        {t("doctor.note")}
                        <textarea
                          value={item.note}
                          onChange={(e) => handleExerciseChange(index, "note", e.target.value)}
                        />
                      </label>
                      <button
                        type="button"
                        className="btn btn--secondary"
                        onClick={() => setPlanForm((prev) => ({ // Видаляємо лише вправу з форми редагування, не документ плану
                          ...prev,
                          exercises: prev.exercises.filter((_, rowIndex) => rowIndex !== index),
                        }))}
                      >
                        {t("doctor.removeExercise")}
                      </button>
                    </div>
                  ))}

                  <div className="assigned-plan-actions">
                    <button
                      type="button"
                      className="btn btn--secondary"
                      onClick={() => setPlanForm((prev) => ({ ...prev, exercises: [...prev.exercises, { ...emptyExercise }] }))}
                    >
                      {t("doctor.addExercise")}
                    </button>
                    <button type="button" className="btn btn--primary" disabled={isSavingPlan} onClick={handleSavePlan}>
                      {t("doctor.savePlan")}
                    </button>
                    <button
                      type="button"
                      className="btn btn--secondary"
                      onClick={() => {
                        setIsEditingPlan(false);
                        setPlanError("");
                        setPlanMessage("");
                      }}
                    >
                      {t("doctor.cancel")}
                    </button>
                  </div>
                </div>
              )}
            </section>

            <section className="doctor-patient-results-section">
              <h2>{t("doctor.exerciseResults")}</h2>
              {exerciseResults.length === 0 ? <p className="doctor-patient-empty">{t("doctor.noExerciseResults")}</p> : exerciseResults.map((item) => (
                <article key={item.id} className="doctor-patient-result-card">
                  <p><strong>{getExerciseDisplayName(item)}</strong></p>
                  <p>{formatDate(item.createdAt, i18n.language)}</p><p>{t("doctor.reps")}: {item.reps ?? 0}</p><p>{t("doctor.seconds")}: {item.seconds ?? 0}</p><p>{t("doctor.mainAngle")}: {item.mainAngle ?? "-"}</p><p>{t("doctor.feedback")}: {localizeMotionText(item.feedback, i18n.language, t) || "-"}</p>{item.warning ? <p>{t("doctor.warning")}: {localizeMotionText(item.warning, i18n.language, t)}</p> : null}
                </article>
              ))}
            </section>

            <section className="doctor-patient-results-section">
              <h2>{t("doctor.workoutResults")}</h2>
              {workoutResults.length === 0 ? <p className="doctor-patient-empty">{t("doctor.noWorkoutResults")}</p> : workoutResults.map((item) => (
                <article key={item.id} className="doctor-patient-result-card">
                  <p><strong>{item.workoutName || item.workoutId}</strong></p>
                  <p>{formatDate(item.createdAt, i18n.language)}</p><p>{t("doctor.totalCompletedReps")} : {item.totalCompletedReps ?? 0}</p><p>{t("doctor.totalTargetReps")} : {item.totalTargetReps ?? 0}</p><p>{t("doctor.seconds")}: {item.seconds ?? 0}</p><p><strong>{t("doctor.completedExercises")}:</strong></p>{Array.isArray(item.completedExercises) && item.completedExercises.length > 0 ? (<ul>{item.completedExercises.map((exercise, index) => (<li key={`${exercise.exerciseId || index}-${index}`}><span>{getExerciseDisplayName(exercise)}</span>{" "}<span>{exercise.completedReps || 0} / {exercise.targetReps || 0}</span></li>))}</ul>) : (<span>-</span>)}
                </article>
              ))}
            </section>
          </>
        )}
      </main>
    </div>
  );
}

export default DoctorPatientProgressPage;
