// ---------------------------------
// *Назва файлу: WeeklyPlanPage.jsx*
// *Опис: Сторінка персонального тижневого плану пацієнта*
// *Що робить: Дозволяє створювати, редагувати та запускати тренування дня з власного плану*
// ---------------------------------
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useAuth } from "../context/useAuth";
import Header from "../components/Header";
import workouts from "../data/workouts";
import exercises from "../exercises";
import { getUserWorkoutResults } from "../services/workoutResultsService";
import {
  createPersonalPlan,
  getPersonalPlanByPatientId,
  updatePersonalPlan,
} from "../services/personalPlansService";

const BODY_PART_TO_WORKOUT = {
  arm: "arm_workout_basic",
  leg: "leg_workout_basic",
  back: "back_workout_basic",
  neck: "neck_workout_basic",
};

const DAY_KEYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];

const getDefaultPersonalDays = () => [
  { dayKey: "monday", type: "training", exercises: [] },
  { dayKey: "tuesday", type: "rest", exercises: [] },
  { dayKey: "wednesday", type: "training", exercises: [] },
  { dayKey: "thursday", type: "rest", exercises: [] },
  { dayKey: "friday", type: "training", exercises: [] },
  { dayKey: "saturday", type: "rest", exercises: [] },
  { dayKey: "sunday", type: "rest", exercises: [] },
];

function WeeklyPlanPage() {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const [selectedBodyPart, setSelectedBodyPart] = useState("arm");
  const [savedThisWeek, setSavedThisWeek] = useState(0);
  const [personalPlan, setPersonalPlan] = useState(null);
  const [personalPlanLoading, setPersonalPlanLoading] = useState(false);
  const [personalPlanError, setPersonalPlanError] = useState("");
  const [personalPlanMessage, setPersonalPlanMessage] = useState("");
  const [editingDayKey, setEditingDayKey] = useState(null);
  const [editingDayDraft, setEditingDayDraft] = useState(null);

  const days = useMemo(() =>
    i18n.language === "en"
      ? ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
      : ["Понеділок", "Вівторок", "Середа", "Четвер", "П’ятниця", "Субота", "Неділя"], [i18n.language]);

  const dayNameByKey = useMemo(() => {
    const names = {};
    DAY_KEYS.forEach((key, index) => {
      names[key] = days[index];
    });
    return names;
  }, [days]);

  const selectedWorkout = useMemo(() => {
    const workoutId = BODY_PART_TO_WORKOUT[selectedBodyPart];
    return workouts.find((item) => item.id === workoutId) || null;
  }, [selectedBodyPart]);

  const exerciseOptions = useMemo(() => exercises.map((exercise) => ({
    id: exercise.id,
    label: i18n.language === "en" ? exercise.nameEn || exercise.name : exercise.name,
    fallbackName: exercise.name,
  })), [i18n.language]);

  const getExerciseLabelById = (exerciseId, fallback) => {
    const found = exerciseOptions.find((item) => item.id === exerciseId);
    if (found) return found.label;
    return fallback || exerciseId || t("common.notAvailable");
  };

  useEffect(() => {
    const loadWorkoutResults = async () => {
      if (!user?.uid || !selectedWorkout?.id) {
        setSavedThisWeek(0);
        return;
      }
      const results = await getUserWorkoutResults(user.uid);
      const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
      const count = results.filter((result) => {
        const isCurrentWorkout = result.workoutId === selectedWorkout.id;
        const createdAt = result.createdAt?.toMillis ? result.createdAt.toMillis() : 0;
        return isCurrentWorkout && createdAt >= weekAgo;
      }).length;
      setSavedThisWeek(count);
    };
    loadWorkoutResults();
  }, [selectedWorkout, user?.uid]);

  useEffect(() => {
    const loadPersonalPlan = async () => {
      if (!user?.uid) {
        setPersonalPlan(null);
        setPersonalPlanError("");
        return;
      }
      try {
        setPersonalPlanLoading(true);
        setPersonalPlanError("");
        const loadedPersonalPlan = await getPersonalPlanByPatientId(user.uid);
        setPersonalPlan(loadedPersonalPlan);
      } catch {
        setPersonalPlanError(t("plan.personalPlanSaveError"));
      } finally {
        setPersonalPlanLoading(false);
      }
    };
    loadPersonalPlan();
  }, [t, user?.uid]);

  const trainingDays = new Set([0, 2, 4]);
  const weekPlan = days.map((dayName, index) => ({ dayName, isTrainingDay: trainingDays.has(index) }));

  const localizedWorkoutTitle = selectedWorkout
    ? i18n.language === "en" ? selectedWorkout.titleEn || selectedWorkout.title : selectedWorkout.title
    : t("plan.noWorkout");

  const localizedWorkoutDescription = selectedWorkout
    ? i18n.language === "en" ? selectedWorkout.descriptionEn || selectedWorkout.description : selectedWorkout.description
    : t("plan.noWorkout");

  const handleCreatePersonalPlan = async () => {
    if (!user?.uid) return;
    try {
      setPersonalPlanLoading(true);
      setPersonalPlanError("");
      setPersonalPlanMessage("");
      const daysTemplate = getDefaultPersonalDays();
      await createPersonalPlan({ patientId: user.uid, title: t("plan.myWeeklyPlan"), days: daysTemplate });
      const createdPlan = await getPersonalPlanByPatientId(user.uid);
      setPersonalPlan(createdPlan);
      setPersonalPlanMessage(t("plan.personalPlanSaved"));
    } catch {
      setPersonalPlanError(t("plan.personalPlanSaveError"));
    } finally {
      setPersonalPlanLoading(false);
    }
  };

  const startEditingDay = (day) => {
    setPersonalPlanError("");
    setPersonalPlanMessage("");
    setEditingDayKey(day.dayKey);
    setEditingDayDraft({ ...day, exercises: (day.exercises || []).map((exercise) => ({ ...exercise })) });
  };

  const cancelEditingDay = () => {
    setEditingDayKey(null);
    setEditingDayDraft(null);
  };

  const handleDraftTypeChange = (value) => {
    setEditingDayDraft((prev) => (prev ? { ...prev, type: value, exercises: value === "rest" ? [] : prev.exercises || [] } : prev));
  };

  const handleAddExerciseToDraft = () => {
    const firstExercise = exerciseOptions[0];
    if (!firstExercise) return;
    setEditingDayDraft((prev) => ({
      ...prev,
      exercises: [...(prev?.exercises || []), { exerciseId: firstExercise.id, exerciseName: firstExercise.fallbackName, targetReps: 8, note: "" }],
    }));
  };

  const handleDraftExerciseChange = (index, field, value) => {
    setEditingDayDraft((prev) => {
      if (!prev) return prev;
      const updatedExercises = (prev.exercises || []).map((item, itemIndex) => {
        if (itemIndex !== index) return item;
        if (field === "exerciseId") {
          const selected = exerciseOptions.find((option) => option.id === value);
          return { ...item, exerciseId: value, exerciseName: selected?.fallbackName || selected?.label || value };
        }
        if (field === "targetReps") return { ...item, targetReps: Number(value) || 0 };
        return { ...item, [field]: value };
      });
      return { ...prev, exercises: updatedExercises };
    });
  };

  const handleRemoveExerciseFromDraft = (index) => {
    setEditingDayDraft((prev) => ({ ...prev, exercises: (prev?.exercises || []).filter((_, itemIndex) => itemIndex !== index) }));
  };

  const handleSaveDay = async () => {
    if (!personalPlan?.id || !editingDayDraft) return;
    try {
      setPersonalPlanError("");
      setPersonalPlanMessage("");
      const updatedDays = (personalPlan.days || []).map((day) => day.dayKey === editingDayKey ? editingDayDraft : day);
      await updatePersonalPlan(personalPlan.id, { title: personalPlan.title || t("plan.myWeeklyPlan"), days: updatedDays });
      setPersonalPlan((prev) => ({ ...prev, days: updatedDays }));
      setPersonalPlanMessage(t("plan.personalPlanSaved"));
      cancelEditingDay();
    } catch {
      setPersonalPlanError(t("plan.personalPlanSaveError"));
    }
  };

  return (<>
    <Header />
    <main className="plan-page"><div className="container">
      <div className="page-top-actions">
        <Link to="/dashboard" className="exercise-back-link exercise-back-link--ui">{t("plan.backToDashboard")}</Link>
      </div>
      <section className="plan-header"><h1>{t("plan.title")}</h1><p>{t("plan.subtitle")}</p><p className="plan-summary">{t("plan.warning")}</p></section>
      <section className="personal-plan-section"><div className="personal-plan-card"><h2>{t("plan.myWeeklyPlan")}</h2>
        {personalPlanLoading ? <p>{t("progress.loading")}</p> : null}
        {!personalPlanLoading && personalPlanError ? <p className="personal-plan-error">{personalPlanError}</p> : null}
        {!personalPlanLoading && personalPlanMessage ? <p className="personal-plan-message">{personalPlanMessage}</p> : null}
        {!personalPlanLoading && !personalPlan && !personalPlanError ? <button type="button" className="btn btn--primary" onClick={handleCreatePersonalPlan}>{t("plan.createMyPlan")}</button> : null}
        {personalPlan ? <div className="personal-plan-day-grid">{(personalPlan.days || []).map((day) => {
          const isTrainingDay = day?.type === "training";
          const dayExercises = day.exercises || [];
          const totalReps = dayExercises.reduce((sum, ex) => sum + (Number(ex.targetReps) || 0), 0);
          return <article key={day.dayKey} className={`personal-plan-day-card ${isTrainingDay ? "personal-plan-day-card--training" : "personal-plan-day-card--rest"}`}>
            <h3>{dayNameByKey[day.dayKey] || day.dayKey}</h3>
            <div className="personal-plan-day-summary">
              <p><strong>{t("plan.dayType")}:</strong> {isTrainingDay ? t("plan.training") : t("plan.rest")}</p>
              {isTrainingDay ? <>
                <div className="personal-plan-day-meta"><span>{t("plan.exerciseCount")}: {dayExercises.length}</span><span>{t("plan.totalReps")}: {totalReps}</span></div>
                {dayExercises.length > 0 ? <ul className="personal-plan-exercise-preview">{dayExercises.slice(0, 3).map((exercise, index) => <li key={`${exercise.exerciseId}-${index}`} className="personal-plan-exercise-preview-item">{getExerciseLabelById(exercise.exerciseId, exercise.exerciseName)}</li>)}{dayExercises.length > 3 ? <li className="personal-plan-exercise-preview-item">{t("plan.moreExercises", { count: dayExercises.length - 3 })}</li> : null}</ul> : <p>{t("plan.dayWorkoutEmpty")}</p>}
              </> : <p>{t("plan.restDayMessage")}</p>}
            </div>
            <div className="personal-plan-day-footer"><div className="personal-plan-day-actions">{isTrainingDay && dayExercises.length > 0 ? <Link className="btn btn--primary" to={`/personal-workout/${day.dayKey}`}>{t("plan.startDayWorkout")}</Link> : null}<button type="button" className="btn btn--secondary" onClick={() => startEditingDay(day)}>{t("plan.editDay")}</button></div></div>
          </article>;
        })}</div> : null}
      </div></section>

      {editingDayDraft ? <div className="plan-modal-overlay" onClick={cancelEditingDay}><div className="plan-modal" onClick={(event) => event.stopPropagation()}>
        <div className="plan-modal-header"><h3>{t("plan.editDayTitle")}</h3><button type="button" className="plan-modal-close" onClick={cancelEditingDay} aria-label={t("plan.close")}>×</button></div>
        <div className="plan-modal-body"><p><strong>{dayNameByKey[editingDayDraft.dayKey] || editingDayDraft.dayKey}</strong></p>
          <div className="personal-plan-form"><label>{t("plan.dayType")}<select value={editingDayDraft.type} onChange={(event) => handleDraftTypeChange(event.target.value)}><option value="training">{t("plan.training")}</option><option value="rest">{t("plan.rest")}</option></select></label>
          {editingDayDraft.type === "training" ? <>{(editingDayDraft.exercises || []).map((exercise, index) => <div key={`${exercise.exerciseId || "exercise"}-${index}`} className="plan-modal-exercise-row personal-plan-exercise-row"><label>{t("plan.exercise")}<select value={exercise.exerciseId || ""} onChange={(event) => handleDraftExerciseChange(index, "exerciseId", event.target.value)}>{exerciseOptions.map((option) => <option key={option.id} value={option.id}>{option.label}</option>)}</select></label><label>{t("plan.targetReps")}<input type="number" min="0" value={exercise.targetReps ?? 0} onChange={(event) => handleDraftExerciseChange(index, "targetReps", event.target.value)} /></label><label>{t("plan.note")}<textarea rows="2" value={exercise.note || ""} onChange={(event) => handleDraftExerciseChange(index, "note", event.target.value)} /></label><button type="button" className="btn btn--secondary" onClick={() => handleRemoveExerciseFromDraft(index)}>{t("plan.removeExercise")}</button></div>)}<button type="button" className="btn btn--secondary" onClick={handleAddExerciseToDraft}>{t("plan.addExercise")}</button></> : null}
          </div></div>
        <div className="plan-modal-actions"><button type="button" className="btn btn--primary" onClick={handleSaveDay}>{t("plan.saveDay")}</button><button type="button" className="btn btn--secondary" onClick={cancelEditingDay}>{t("plan.cancel")}</button></div>
      </div></div> : null}

      <section className="recommendation-section">
            <h2>{t("plan.problemRecommendations")}</h2>
            <p className="plan-summary">{t("plan.recommendationDescription")}</p>
            <div className="recommendation-area-tabs">
              <h3>{t("plan.chooseBodyPart")}</h3>
            <div className="plan-body-grid">
              {Object.keys(BODY_PART_TO_WORKOUT).map((bodyPart) => (
                <button
                  key={bodyPart}
                  type="button"
                  className={`plan-option-card ${selectedBodyPart === bodyPart ? "plan-option-card--active" : ""}`}
                  onClick={() => setSelectedBodyPart(bodyPart)}
                >
                  {t(`plan.${bodyPart}`)}
                </button>
              ))}
            </div>
            </div>
            <p className="plan-summary">{t("plan.savedThisWeek")}: {savedThisWeek}</p>
            <h3>{t("plan.recommendationTemplate")}</h3>
            <div className="plan-week-grid recommendation-template-grid">
              {weekPlan.map((day) => (
                <article key={day.dayName} className={`plan-day-card recommendation-day-card ${day.isTrainingDay ? "" : "plan-day-card--rest"} ${day.isTrainingDay && savedThisWeek > 0 ? "plan-day-card--done" : ""}`}>
                  <p className="plan-day-label">{day.dayName}</p>
                  {day.isTrainingDay ? (
                    <>
                      <h3 className="plan-day-title">{t("plan.trainingDay")}</h3>
                      <p className="plan-day-title">{localizedWorkoutTitle}</p>
                      <p className="plan-day-description">{localizedWorkoutDescription}</p>
                      {selectedWorkout ? <Link className="nav-register" to={`/workout/${selectedWorkout.id}`}>{t("plan.startWorkout")}</Link> : null}
                    </>
                  ) : (
                    <>
                      <h3 className="plan-day-title">{t("plan.restDay")}</h3>
                      <p className="plan-day-description">{t("plan.restDescription")}</p>
                    </>
                  )}
                </article>
              ))}
            </div>
          </section>
    </div></main>
  </>);
}

export default WeeklyPlanPage;