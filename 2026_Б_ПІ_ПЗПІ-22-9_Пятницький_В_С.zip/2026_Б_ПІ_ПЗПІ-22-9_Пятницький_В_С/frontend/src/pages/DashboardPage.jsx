// ---------------------------------
// *Назва файлу: DashboardPage.jsx*
// *Опис: Сторінка особистого кабінету пацієнта*
// *Що робить: Відображає доступні вправи, готові заняття та швидкі переходи до плану, прогресу і зв’язку з лікарем*
// ---------------------------------
import { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { useAuth } from "../context/useAuth";
import Header from "../components/Header";
import bodyParts from "../data/bodyParts";
import rehabExercises from "../exercises/index.js";
import workouts from "../data/workouts/index.js";

function DashboardPage() {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();

  const [selectedBodyPart, setSelectedBodyPart] = useState(null);
  const userName = user?.displayName || user?.email || "User";

  const selectedExercises = useMemo(() => {
    if (!selectedBodyPart) return [];
    return rehabExercises.filter((exercise) => selectedBodyPart.exercises.includes(exercise.id));
  }, [selectedBodyPart]);

  const getExerciseName = (exercise) =>
    i18n.language === "en" ? exercise.nameEn || exercise.name : exercise.name;

  const getExerciseDescription = (exercise) => {
    if (i18n.language === "en") {
      return exercise.descriptionEn || t("dashboard.exerciseDescriptionFallback");
    }
    return exercise.description || t("dashboard.exerciseDescriptionFallback");
  };

  const getBodyPartName = (part) => t(`catalog.bodyParts.${part.id}`);
  const getBodyPartDescription = (part) => t(`dashboard.areaDescriptions.${part.id}`);

  return (
    <>
      <Header />

      <main className="dashboard-page">
        <div className="container">
          <section className="dashboard-welcome dashboard-welcome-card">
            <div className="dashboard-welcome-content">
              <p className="page-badge">{t("dashboard.label")}</p>
              <h1>{t("dashboard.welcome", { name: userName })}</h1>
              <p className="dashboard-text">{t("dashboard.welcomeDescription")}</p>
            </div>

            <div className="dashboard-quick-actions">
              <Link to="/plan" className="btn btn--secondary">
                {t("dashboard.quickPlan")}
              </Link>
              <Link to="/progress" className="btn btn--secondary">
                {t("dashboard.quickProgress")}
              </Link>
              <Link to="/doctor-connection" className="btn btn--secondary">
                {t("dashboard.quickDoctorConnection")}
              </Link>
            </div>
          </section>

          <section className="dashboard-section">
            <div className="dashboard-section-header">
              <h2 className="dashboard-section-title">{t("dashboard.singleExercises")}</h2>
            </div>
            <p className="dashboard-section-subtitle">{t("dashboard.singleExercisesSubtitle")}</p>

            <div className="dashboard-grid">
              {bodyParts.map((part) => (
                <button
                  key={part.id}
                  type="button"
                  className={`dashboard-card dashboard-area-card ${selectedBodyPart?.id === part.id ? "dashboard-card--active dashboard-area-card--active" : ""}`}
                  onClick={() => setSelectedBodyPart(part)}
                >
                  <h3>{getBodyPartName(part)}</h3>
                  <p>{getBodyPartDescription(part)}</p>
                  <p className="dashboard-card-meta meta-badge">
                    {t("dashboard.exerciseCount", { count: part.exercises.length })}
                  </p>
                </button>
              ))}
            </div>
          </section>

          {selectedBodyPart && (
            <section className="dashboard-selected-panel">
              <p>
                {t("dashboard.selectedAreaCompact", {
                  name: getBodyPartName(selectedBodyPart),
                  count: selectedBodyPart.exercises.length,
                })}
              </p>
              <button type="button" className="btn btn--secondary" onClick={() => setSelectedBodyPart(null)}>
                {t("dashboard.clearSelection")}
              </button>
            </section>
          )}

          {selectedBodyPart && selectedExercises.length > 0 && (
            <section className="dashboard-exercises dashboard-exercises--recommended">
              <h2 className="dashboard-section-title">{t("dashboard.exerciseTitle")}</h2>

              <div className="dashboard-grid dashboard-recommended-grid">
                {selectedExercises.map((exercise) => (
                  <article key={exercise.id} className="dashboard-card dashboard-recommended-card">
                    <h3>{getExerciseName(exercise)}</h3>
                    <p>{getExerciseDescription(exercise)}</p>
                    <Link to={`/exercise/${exercise.id}`} className="btn btn--primary">
                      {t("dashboard.startExercise")}
                    </Link>
                  </article>
                ))}
              </div>
            </section>
          )}

          <section className="dashboard-section dashboard-exercises">
            <div className="dashboard-section-header">
              <h2 className="dashboard-section-title">{t("dashboard.readyWorkouts")}</h2>
            </div>
            <p className="dashboard-section-subtitle">{t("dashboard.readyWorkoutsSubtitle")}</p>

            <div className="dashboard-grid">
              {workouts.map((workout) => (
                <article key={workout.id} className="dashboard-card dashboard-workout-card">
                  <h3>{i18n.language === "en" ? workout.titleEn || workout.title : workout.title}</h3>
                  <p>{i18n.language === "en" ? workout.descriptionEn || workout.description : workout.description}</p>
                  <p className="dashboard-card-meta meta-badge">
                    {t("dashboard.workoutExercisesCount", { count: workout.exercises.length })}
                  </p>
                  <Link to={`/workout/${workout.id}`} className="btn btn--primary">
                    {t("dashboard.startWorkout")}
                  </Link>
                </article>
              ))}
            </div>
          </section>
        </div>
      </main>
    </>
  );
}

export default DashboardPage;