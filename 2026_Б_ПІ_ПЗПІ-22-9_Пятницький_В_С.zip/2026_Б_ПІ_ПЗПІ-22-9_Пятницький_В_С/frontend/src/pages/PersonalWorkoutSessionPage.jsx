// ---------------------------------
// *Назва файлу: PersonalWorkoutSessionPage.jsx*
// *Опис: Сторінка виконання тренування дня з персонального плану*
// *Що робить: Завантажує вправи конкретного дня, аналізує виконання через MediaPipe та зберігає результат тренування*
// ---------------------------------
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import Header from "../components/Header";
import rehabExercises from "../exercises/index.js";
import usePoseDetection from "../hooks/usePoseDetection";
import { useAuth } from "../context/useAuth";
import { getPersonalPlanByPatientId } from "../services/personalPlansService";
import { saveWorkoutResult } from "../services/workoutResultsService";
import { localizeMotionText } from "../utils/localizeMotionText";
import { getExerciseGuidance } from "../utils/getExerciseGuidance";
import useStableValue from "../hooks/useStableValue";

const DAY_KEYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];

function formatTime(totalSeconds) {
  const mins = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const secs = String(totalSeconds % 60).padStart(2, "0");
  return `${mins}:${secs}`;
}

function normalizeAnalyzeResult(result) {
  if (typeof result === "string") return { message: result, feedback: "", warning: "" };
  if (result && typeof result === "object") return { message: result.message || "", feedback: result.feedback || "", warning: result.warning || "" };
  return { message: "no analysis yet", feedback: "", warning: "" };
}

function PersonalWorkoutSessionPage() {
  const { t, i18n } = useTranslation();
  const { dayKey } = useParams();
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [day, setDay] = useState(null);
  const [sessionSteps, setSessionSteps] = useState([]);
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [isWorkoutStarted, setIsWorkoutStarted] = useState(false);
  const [isWorkoutCompleted, setIsWorkoutCompleted] = useState(false);
  const [isWorkoutFinished, setIsWorkoutFinished] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [completedRepsByExercise, setCompletedRepsByExercise] = useState({});
  const [isSavingResult, setIsSavingResult] = useState(false);
  const [isResultSaved, setIsResultSaved] = useState(false);
  const [saveState, setSaveState] = useState("idle");

  const cameraSectionRef = useRef(null);

  const dayNamesByKey = useMemo(() => {
    const labels = i18n.language === "en"
      ? ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
      : ["Понеділок", "Вівторок", "Середа", "Четвер", "П’ятниця", "Субота", "Неділя"];

    return DAY_KEYS.reduce((acc, key, index) => ({ ...acc, [key]: labels[index] }), {});
  }, [i18n.language]);

  useEffect(() => {
    const load = async () => {
      if (!user?.uid || !dayKey) return;
      try {
        setLoading(true);
        setError("");
        const plan = await getPersonalPlanByPatientId(user.uid);
        const foundDay = (plan?.days || []).find((item) => item.dayKey === dayKey);
        setDay(foundDay || null);

        // Нормалізація вправ дня у sessionSteps для локальної сесії тренування
        const normalizedSteps = (foundDay?.exercises || []).map((exercise) => {
          const targetReps = Math.max(1, Number(exercise?.targetReps || exercise?.reps || 1));
          return {
            exerciseId: exercise?.exerciseId || "",
            exerciseName: exercise?.exerciseName || "",
            name: exercise?.exerciseName || exercise?.name || "",
            reps: targetReps,
            targetReps,
            note: exercise?.note || "",
          };
        });
        setSessionSteps(normalizedSteps);
        setCompletedRepsByExercise({});
        setIsResultSaved(false);
        setIsWorkoutFinished(false);
        setSaveState("idle");
      } catch {
        setError(t("common.error"));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [dayKey, t, user?.uid]);

  const currentStep = sessionSteps[currentExerciseIndex] || null;
  const currentExercise = useMemo(() => rehabExercises.find((item) => item.id === currentStep?.exerciseId) || null, [currentStep]);
  const getLocalizedExerciseName = useCallback((exerciseId, fallbackName) => {
    const found = rehabExercises.find((item) => item.id === exerciseId);
    if (found) return i18n.language === "en" && found.nameEn ? found.nameEn : found.name;
    return fallbackName || t("common.notAvailable");
  }, [i18n.language, t]);

  // Аналіз позі для поточної вправи у персональному занятті
  const analyzePose = useCallback(({ landmarks, stageRef, lastRepTimeRef, setMainAngle, setExerciseStage, setReps }) => {
    if (!landmarks || landmarks.length === 0) {
      setMainAngle(0);
      setExerciseStage("start");
      stageRef.current = "start";
      return { message: t("exercise.humanNotFound"), feedback: t("exercise.standInFront"), warning: "" };
    }

    if (!currentExercise || typeof currentExercise.analyze !== "function") {
      return { message: t("exercise.analysisUnavailable"), feedback: "", warning: "" };
    }

    const pose = landmarks[0];
    const rawResult = currentExercise.analyze({ pose, stageRef, lastRepTimeRef, setMainAngle, setExerciseStage, setReps });
    return normalizeAnalyzeResult(rawResult);
  }, [currentExercise, t]);

  const { videoRef, canvasRef, isCameraOn, cameraError, status, tip, feedback, warning, isModelReady, mainAngle, reps, exerciseStage, setTip, setFeedback, setWarning, startCamera, stopCamera, resetPoseState } = usePoseDetection({ analyzePose, cameraErrorText: t("exercise.cameraError") });

  const totalExercises = sessionSteps.length;
  const totalTargetReps = sessionSteps.reduce((sum, step) => sum + (Number(step.targetReps) || 0), 0);

  const resetCurrentExerciseState = useCallback(() => {
    resetPoseState();
    setTip(t("exercise.standInFront"));
  }, [resetPoseState, setTip, t]);

  const persistCurrentExerciseReps = useCallback(() => {
    if (!sessionSteps[currentExerciseIndex]) return;
    const exerciseKey = `${sessionSteps[currentExerciseIndex]?.exerciseId || "exercise"}-${currentExerciseIndex}`;
    setCompletedRepsByExercise((prev) => ({
      ...prev,
      [exerciseKey]: Math.max(Number(prev[exerciseKey] || 0), Number(reps) || 0),
    }));
  }, [currentExerciseIndex, reps, sessionSteps]);

  const completeWorkoutSession = useCallback(() => {
    persistCurrentExerciseReps();
    setIsWorkoutStarted(false);
    setIsWorkoutCompleted(true);
    setIsWorkoutFinished(true);
    setFeedback(t("plan.dayWorkoutCompleted"));
    setWarning("");
  }, [persistCurrentExerciseReps, setFeedback, setWarning, t]);

  const goToNextExercise = useCallback(() => {
    persistCurrentExerciseReps();
    // Перехід до наступної вправи або завершення дня, якщо це остання вправа
    if (currentExerciseIndex >= sessionSteps.length - 1) {
      completeWorkoutSession();
      return;
    }

    setCurrentExerciseIndex((prev) => prev + 1);
    resetCurrentExerciseState();
  }, [completeWorkoutSession, currentExerciseIndex, persistCurrentExerciseReps, resetCurrentExerciseState, sessionSteps.length]);


  const guidanceText = getExerciseGuidance({
    exerciseId: currentStep?.exerciseId,
    exerciseName: getLocalizedExerciseName(currentStep?.exerciseId, currentStep?.exerciseName || currentStep?.name),
    stage: exerciseStage,
    feedback,
    warning,
    reps,
    targetReps: Number(currentStep?.targetReps) || 0,
    language: i18n.language,
    t,
  });


  const stableFeedback = useStableValue(feedback, 400);
  const stableWarning = useStableValue(warning, 700);
  const stableGuidance = useStableValue(guidanceText, 400);

  const completedTargetReps = sessionSteps.slice(0, currentExerciseIndex).reduce((sum, step) => sum + (Number(step.targetReps) || 0), 0);

  const updateStepReps = (index, value) => {
    setSessionSteps((prev) => prev.map((step, stepIndex) => (stepIndex === index ? { ...step, targetReps: Math.max(1, Number(value) || 1), reps: Math.max(1, Number(value) || 1) } : step)));
  };

  const completedExercises = useMemo(() => sessionSteps.map((step, index) => {
    const exerciseKey = `${step.exerciseId || "exercise"}-${index}`;
    const completedReps = Number(completedRepsByExercise[exerciseKey] || 0);
    return {
      exerciseId: step.exerciseId,
      exerciseName: step.exerciseName || step.name || "",
      targetReps: Number(step.targetReps) || 0,
      completedReps,
    };
  }), [completedRepsByExercise, sessionSteps]);

  const totalCompletedReps = completedExercises.reduce((sum, exercise) => sum + (Number(exercise.completedReps) || 0), 0);
  const hasCompletedAnyReps = totalCompletedReps > 0 || completedExercises.some((exercise) => Number(exercise.completedReps) > 0);

  useEffect(() => {
    let interval = null;
    if (isWorkoutStarted && !isWorkoutCompleted) interval = setInterval(() => setSeconds((prev) => prev + 1), 1000);
    return () => interval && clearInterval(interval);
  }, [isWorkoutStarted, isWorkoutCompleted]);

  const handleFullscreen = async () => {
    if (!cameraSectionRef.current) return;
    if (document.fullscreenElement) await document.exitFullscreen();
    else await cameraSectionRef.current.requestFullscreen();
  };

  const handleSaveResult = async () => {
    if (!isWorkoutFinished || !user?.uid || !dayKey || sessionSteps.length === 0 || isResultSaved || isSavingResult || !hasCompletedAnyReps) return;

    try {
      setIsSavingResult(true);
      setSaveState("idle");
      await saveWorkoutResult({
        userId: user.uid,
        userEmail: user.email || "",
        workoutId: `personal-${dayKey}`,
        workoutName: `${t("plan.myPlan")}: ${dayNamesByKey[day?.dayKey] || dayNamesByKey[dayKey] || dayKey}`,
        seconds,
        totalTargetReps,
        totalCompletedReps,
        completedExercises,
        source: "personalPlan",
        dayKey,
      });
      setIsResultSaved(true);
      setSaveState("success");
    } catch {
      setSaveState("error");
    } finally {
      setIsSavingResult(false);
    }
  };

  return (
    <>
      <Header />
      <main className="exercise-page personal-workout-session-page"><div className="container">
        <div className="page-top-actions"><Link to="/plan" className="exercise-back-link exercise-back-link--ui">← {t("plan.backToPlan")}</Link></div>

        <section className="exercise-main-card personal-workout-session-card">
          <p className="page-badge">{t("plan.myPlan")}</p>
          <h1>{t("plan.dayWorkout")}</h1>
          <p className="exercise-description">{t("plan.dayWorkoutSubtitle")}</p>

          {loading ? <p className="app-state app-state--loading">{t("common.loading")}</p> : null}
          {!loading && error ? <p className="app-state app-state--error">{error}</p> : null}
          {!loading && !error && !day ? <p className="app-state app-state--error">{t("plan.dayNotFound")}</p> : null}
          {!loading && day?.type === "rest" ? <p className="app-state app-state--empty">{t("plan.restDayMessage")}</p> : null}
          {!loading && day?.type === "training" && sessionSteps.length === 0 ? <p className="app-state app-state--empty">{t("plan.dayWorkoutEmpty")}</p> : null}

          {!loading && day?.type === "training" && sessionSteps.length > 0 ? (
            <div className="exercise-status-box session-info-grid personal-workout-status-grid">
              <div className="session-info-section">
                <h3 className="workout-status-group-title session-info-section-title">{t("workout.progressTitle")}</h3>
                <p className="info-row session-info-row"><span className="info-row__label session-info-label">{t("plan.day")}:</span><span className="info-row__value session-info-value">{dayNamesByKey[day.dayKey] || dayNamesByKey[dayKey] || t("common.notAvailable")}</span></p>
                <p className="info-row session-info-row"><span className="info-row__label session-info-label">{t("plan.workoutTime")}:</span><span className="info-row__value session-info-value">{formatTime(seconds)}</span></p>
                <p className="info-row session-info-row"><span className="info-row__label session-info-label">{t("workout.step")}:</span><span className="info-row__value session-info-value">{Math.min(currentExerciseIndex + 1, totalExercises)} / {totalExercises}</span></p>
                <p className="info-row session-info-row"><span className="info-row__label session-info-label">{t("workout.targetReps")}:</span><span className="info-row__value session-info-value">{currentStep?.targetReps || 0}</span></p>
                <p className="info-row session-info-row"><span className="info-row__label session-info-label">{t("workout.completedReps")}:</span><span className="info-row__value session-info-value">{reps}</span></p>
                <p className="info-row session-info-row"><span className="info-row__label session-info-label">{t("workout.totalVolume")}:</span><span className="info-row__value session-info-value">{completedTargetReps + reps} / {totalTargetReps}</span></p>
                <p className="info-row session-info-row"><span className="info-row__label session-info-label">{t("workout.sessionStatus")}:</span><span className="info-row__value session-info-value">{isWorkoutCompleted ? t("workout.statusCompleted") : isWorkoutStarted ? t("workout.statusActive") : t("workout.statusReady")}</span></p>
              </div>
              <div className="session-info-section">
                <h3 className="workout-status-group-title session-info-section-title">{t("workout.aiAnalysisTitle")}</h3>
                <p className="info-row session-info-row"><span className="info-row__label session-info-label">{t("exercise.aiStatus")}:</span><span className="info-row__value session-info-value">{t(`status.${status}`, { defaultValue: status })}</span></p>
                <p className="info-row session-info-row"><span className="info-row__label session-info-label">{t("exercise.model")}:</span><span className="info-row__value session-info-value">{isModelReady ? t("exercise.modelReady") : t("exercise.modelLoading")}</span></p>
                <p className="info-row session-info-row"><span className="info-row__label session-info-label">{t("exercise.mainAngle")}:</span><span className="info-row__value session-info-value">{mainAngle}°</span></p>
                <p className="info-row session-info-row"><span className="info-row__label session-info-label">{t("exercise.exerciseStage")}:</span><span className="info-row__value session-info-value">{t(`status.${exerciseStage}`, { defaultValue: exerciseStage })}</span></p>
              </div>
            </div>
          ) : null}

          {!loading && day?.type === "training" && sessionSteps.length > 0 ? (
            <div className="exercise-actions personal-workout-actions session-action-row">
              {!isWorkoutStarted && !isWorkoutFinished ? <button type="button" className="btn btn--primary" onClick={() => { setSeconds(0); setCurrentExerciseIndex(0); setIsWorkoutStarted(true); setIsWorkoutCompleted(false); setIsWorkoutFinished(false); setIsResultSaved(false); setSaveState("idle"); resetCurrentExerciseState(); }}>{t("plan.startWorkout")}</button> : null}
              {isWorkoutStarted && currentExerciseIndex < totalExercises - 1 ? <button type="button" className="btn btn--secondary" onClick={goToNextExercise}>{t("plan.nextExercise")}</button> : null}
              {isWorkoutStarted ? <button type="button" className="btn btn--secondary" onClick={completeWorkoutSession}>{t("plan.finishWorkout")}</button> : null}
                          </div>
          ) : null}

          {!loading && isWorkoutFinished && sessionSteps.length > 0 ? (
            <div className="session-result-card">
              <h3 className="session-result-title">{t("plan.dayWorkoutCompleted")}</h3>
              <div className="session-result-actions">
                {user && !isResultSaved ? (
                  <button type="button" className="btn btn--primary" onClick={handleSaveResult} disabled={isSavingResult || !hasCompletedAnyReps}>
                    {t("plan.saveDayWorkoutResult")}
                  </button>
                ) : null}
                <Link to="/plan" className="btn btn--secondary">{t("plan.backToPlan")}</Link>
              </div>
              <div className={`session-result-hint ${
                saveState === "success"
                  ? "session-result-hint--success"
                  : saveState === "error"
                    ? "session-result-hint--error"
                    : "session-result-hint--warning"
              }`}>
                {saveState === "success"
                  ? t("plan.dayWorkoutSaved")
                  : saveState === "error"
                    ? t("plan.dayWorkoutSaveError")
                    : hasCompletedAnyReps
                      ? t("plan.dayWorkoutSaveHint")
                      : t("plan.dayWorkoutSaveRequiresReps")}
              </div>
            </div>
          ) : null}
        </section>

        {!loading && day?.type === "training" && sessionSteps.length > 0 ? (
          <section className="exercise-main-card personal-workout-playlist">
            <p className="exercise-label">{t("plan.exercisePlaylist")}</p>
            <div className="dashboard-grid">
              {sessionSteps.map((step, index) => {
                const isActive = index === currentExerciseIndex;
                const isDone = index < currentExerciseIndex;
                return (
                  <article key={`${step.exerciseId}-${index}`} className={`dashboard-card workout-playlist-card ${isActive ? "dashboard-card--active workout-playlist-card--active" : ""} ${isDone ? "workout-playlist-card--done" : ""}`}>
                    <h3>{getLocalizedExerciseName(step.exerciseId, step.exerciseName || step.name)}</h3>
                    {step.note ? <p>{t("plan.note")}: {step.note}</p> : null}
                    <p className="workout-step-status-row"><span className="workout-step-status-label">{t("workout.status")}:</span> <span className="workout-status-badge meta-badge">{isDone ? t("plan.completed") : isActive ? t("plan.current") : t("plan.waiting")}</span></p>
                    <div className="workout-reps-control"><button type="button" className="btn btn--secondary workout-reps-btn" onClick={() => updateStepReps(index, step.targetReps - 1)} disabled={isWorkoutStarted}>-</button><input type="number" className="workout-reps-input" min="1" value={step.targetReps} onChange={(e) => updateStepReps(index, e.target.value)} disabled={isWorkoutStarted} /><button type="button" className="btn btn--secondary workout-reps-btn" onClick={() => updateStepReps(index, step.targetReps + 1)} disabled={isWorkoutStarted}>+</button></div>
                  </article>
                );
              })}
            </div>
          </section>
        ) : null}

        {!loading && day?.type === "training" && sessionSteps.length > 0 ? (
          <section className="exercise-camera-section personal-workout-camera-section" ref={cameraSectionRef}>
            <div className="exercise-camera-header"><h2>{t("exercise.cameraTitle")}</h2><button type="button" className="btn btn--secondary" onClick={handleFullscreen}>{t("exercise.fullscreen")}</button></div>
            <div className="exercise-camera-large">
              <video ref={videoRef} autoPlay playsInline muted className={`exercise-video ${!isCameraOn ? "exercise-video--hidden" : ""}`} />
              <canvas ref={canvasRef} className={`exercise-canvas ${!isCameraOn ? "exercise-video--hidden" : ""}`} />
              {!isCameraOn ? <div className="exercise-camera-placeholder"><p>{t("exercise.cameraOff")}</p></div> : null}
              <div className="exercise-overlay exercise-overlay--bottom"><div className="exercise-hint-box"><p>{tip || t("exercise.noFeedback")}</p><small className="exercise-ai-status">{localizeMotionText(stableFeedback, i18n.language) || (isModelReady ? t("common.aiReady") : t("common.aiLoading"))}</small></div></div>
            </div>
            {cameraError ? <div className="exercise-camera-error"><p>{cameraError}</p></div> : null}
            <div className="exercise-actions exercise-actions--camera">{!isCameraOn ? <button type="button" className="btn btn--primary" onClick={startCamera} disabled={!isModelReady}>{t("exercise.cameraStart")}</button> : <button type="button" className="btn btn--secondary" onClick={() => { stopCamera(); resetCurrentExerciseState(); }}>{t("exercise.cameraStop")}</button>}</div>
            <div className="camera-status-overlay">
              <p className="camera-status-overlay__title">{getLocalizedExerciseName(currentStep?.exerciseId, currentStep?.exerciseName || currentStep?.name)}</p>
              <p className="camera-status-overlay__meta">
                {t("exercise.stepProgress", { current: Math.min(currentExerciseIndex + 1, totalExercises), total: totalExercises })}
                {" · "}
                {t("exercise.completedProgress", { completed: reps, target: currentStep?.targetReps || 0 })}
              </p>
              <p className="camera-status-overlay__hint">{stableGuidance || t("exercise.cameraStatusDefault")}</p>
            </div>
            {stableWarning ? (
              <div className="camera-warning-box">
                <p>{t("exercise.warningPrefix", { message: localizeMotionText(stableWarning, i18n.language) })}</p>
              </div>
            ) : null}
          </section>
        ) : null}
      </div></main>
    </>
  );
}

export default PersonalWorkoutSessionPage;