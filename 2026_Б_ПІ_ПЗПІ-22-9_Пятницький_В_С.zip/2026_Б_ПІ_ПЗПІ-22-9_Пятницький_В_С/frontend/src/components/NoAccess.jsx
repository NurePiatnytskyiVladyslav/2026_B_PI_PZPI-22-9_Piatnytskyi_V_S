// ---------------------------------
// *Назва файлу: NoAccess.jsx*
// *Опис: Компонент сторінки відмови в доступі*
// *Що робить: Відображає повідомлення про відсутність прав доступу до розділу*
// ---------------------------------
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useAuth } from "../context/useAuth";

function NoAccess() {
  const { t } = useTranslation();
  const { isDoctor } = useAuth();

  return (
    <div className="app-state app-state--error">
      <p>{t("common.noAccess")}</p>
      <Link className="btn btn--primary" to={isDoctor ? "/doctor" : "/dashboard"}>
        {t("common.backToDashboard")}
      </Link>
    </div>
  );
}

export default NoAccess;