// ---------------------------------
// *Назва файлу: AuthModal.jsx*
// *Опис: Компонент модального вікна для аутентифікації користувача (реєстрація та вхід)*
// *Що робить: Відображає модальне вікно для реєстрації та входу користувача*
// ---------------------------------
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { auth } from "../firebase/firebase";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
} from "firebase/auth";
import { createUserProfileIfNotExists } from "../services/userService";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function AuthModal({ isOpen, onClose, mode: initialMode }) {
  const { t } = useTranslation();
  const [mode, setMode] = useState("login");

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setMode(initialMode || "login");
      setError("");
      setSuccess("");
    }
  }, [isOpen, initialMode]);

  if (!isOpen) return null;

  const clearForm = () => {
    setName("");
    setEmail("");
    setPassword("");
    setError("");
    setSuccess("");
  };

  const handleClose = () => {
    clearForm();
    setMode("login");
    onClose();
  };

  const handleSwitchMode = () => {
    setError("");
    setSuccess("");
    setName("");
    setEmail("");
    setPassword("");
    setMode((prevMode) => (prevMode === "login" ? "register" : "login"));
  };

  const validateForm = () => {
    if (mode === "register" && !name.trim()) {
      return t("auth.nameRequired");
    }

    if (!email.trim()) {
      return t("auth.emailRequired");
    }

    if (!EMAIL_REGEX.test(email.trim())) {
      return t("auth.invalidEmail");
    }

    if (!password) {
      return t("auth.passwordRequired");
    }

    if (mode === "register" && password.length < 6) {
      return t("auth.weakPassword");
    }

    return "";
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setSuccess("");

    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }

    try {
      setLoading(true);

      if (mode === "register") {
        const userCredential = await createUserWithEmailAndPassword(
          auth,
          email.trim(),
          password,
        );

        await updateProfile(userCredential.user, {
          displayName: name.trim(),
        });

        await createUserProfileIfNotExists({
          ...userCredential.user,
          displayName: name.trim(),
        });

        setSuccess(t("auth.registerSuccess"));
        clearForm();

        setTimeout(() => {
          onClose();
        }, 1000);
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), password);

        setSuccess(t("auth.loginSuccess"));
        clearForm();

        setTimeout(() => {
          onClose();
        }, 1000);
      }
    } catch (err) {
      if (err.code === "auth/email-already-in-use") {
        setError(t("auth.emailInUse"));
      } else if (err.code === "auth/invalid-email") {
        setError(t("auth.invalidEmail"));
      } else if (err.code === "auth/weak-password") {
        setError(t("auth.weakPassword"));
      } else if (err.code === "auth/user-not-found") {
        setError(t("auth.userNotFound"));
      } else if (err.code === "auth/wrong-password") {
        setError(t("auth.wrongPassword"));
      } else if (err.code === "auth/invalid-credential") {
        setError(t("auth.invalidCredentials"));
      } else {
        setError(t("auth.unknownError"));
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={handleClose}>
      <div className="modal" onClick={(event) => event.stopPropagation()}>
        <button type="button" className="modal-close" onClick={handleClose}>
          ×
        </button>

        <h2>
          {mode === "login" ? t("auth.loginTitle") : t("auth.registerTitle")}
        </h2>

        <p className="auth-subtitle">
          {mode === "login"
            ? t("auth.loginSubtitle")
            : t("auth.registerSubtitle")}
        </p>

        <form className="auth-form" onSubmit={handleSubmit}>
          {mode === "register" && (
            <input
              type="text"
              placeholder={t("auth.name")}
              value={name}
              onChange={(event) => setName(event.target.value)}
            />
          )}

          <input
            type="email"
            placeholder={t("auth.email")}
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />

          <input
            type="password"
            placeholder={t("auth.password")}
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />

          {error && <p className="auth-message auth-message--error">{error}</p>}

          {success && (
            <p className="auth-message auth-message--success">{success}</p>
          )}

          <button type="submit" className="btn btn--primary auth-btn">
            {loading
              ? "..."
              : mode === "login"
                ? t("auth.loginButton")
                : t("auth.registerButton")}
          </button>
        </form>

        <p className="auth-switch">
          {mode === "login" ? t("auth.noAccount") : t("auth.haveAccount")}{" "}
          <button
            type="button"
            className="auth-switch-button"
            onClick={handleSwitchMode}
          >
            {mode === "login" ? t("auth.switchToRegister") : t("auth.switchToLogin")}
          </button>
        </p>
      </div>
    </div>
  );
}

export default AuthModal;