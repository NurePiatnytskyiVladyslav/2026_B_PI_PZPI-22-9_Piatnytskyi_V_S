// ---------------------------------
// *Назва файлу: Footer.jsx*
// *Опис: Компонент нижнього колонтитула застосунку*
// *Що робить: Відображає інформаційний футер з додатковими посиланнями та службовим текстом*
// ---------------------------------
import { useTranslation } from "react-i18next";
import { APP_VERSION } from "../config/appVersion";

function Footer() {
  // Беремо функцію перекладу
  const { t } = useTranslation();

  return (
    <footer className="footer">
      <div className="container">
        <p>{t("footer.text")}</p>
        <p className="footer-version">{t("footer.version")}: v{APP_VERSION}</p>
      </div>
    </footer>
  );
}

export default Footer;