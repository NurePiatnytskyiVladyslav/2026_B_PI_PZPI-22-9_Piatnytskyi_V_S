// ---------------------------------
// *Назва файлу: ProtectedRoute.jsx*
// *Опис: Компонент захищеного маршруту*
// *Що робить: Перевіряє автентифікацію користувача та обмежує доступ до приватних сторінок*
// ---------------------------------
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/useAuth";
import NoAccess from "./NoAccess";

// Route guard: перевіряємо авторизацію та роль для доступу до сторінки
function ProtectedRoute({ children, allowedRoles = [] }) {
  const { user, role } = useAuth();

  // Якщо користувач не увійшов, перекидаємо на головну
  if (!user) {
    return <Navigate to="/" replace />;
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(role)) {
    return <NoAccess />;
  }

  // Якщо користувач увійшов, показуємо сторінку
  return children;
}

export default ProtectedRoute;