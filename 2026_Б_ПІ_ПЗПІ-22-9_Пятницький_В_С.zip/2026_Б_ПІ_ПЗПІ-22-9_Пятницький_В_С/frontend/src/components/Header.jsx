// ---------------------------------
// *Назва файлу: Header.jsx*
// *Опис: Компонент верхньої навігаційної панелі застосунку*
// *Що робить: Відображає логотип, навігацію, перемикач мови, ім’я користувача та кнопку виходу*
// ---------------------------------
import { useTranslation } from "react-i18next";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/useAuth";

function Header({ onOpenLogin, onOpenRegister }) {
  const { t, i18n } = useTranslation();
  const { user, isDoctor, isPatient, logout } = useAuth();
  const navigate = useNavigate();

  // Зміна мови
  const changeLanguage = (lang) => {
    i18n.changeLanguage(lang);
    localStorage.setItem("language", lang);
  };

  // Ім'я користувача: спочатку displayName, якщо його нема — email
  const userName = user?.displayName || user?.email || "User";

  return (
    <header className="header">
      <div className="container header__content">
        <button type="button" className="logo logo-button" onClick={() => navigate(isDoctor ? "/doctor" : "/dashboard")}>RehabAI</button>

        <nav className="nav">
          {user ? (
            <div className="header-user-block">
              <div className="header-main-nav">
                {isPatient && (
                  <>
                    <NavLink to="/progress" className={({ isActive }) => `nav-btn ${isActive ? "nav-btn--active" : ""}`}>
                      {t("header.progress")}
                    </NavLink>

                    <NavLink to="/plan" className={({ isActive }) => `nav-btn ${isActive ? "nav-btn--active" : ""}`}>
                      {t("header.plan")}
                    </NavLink>

                    <NavLink to="/doctor-connection" className={({ isActive }) => `nav-btn ${isActive ? "nav-btn--active" : ""}`}>
                      {t("header.doctorConnection")}
                    </NavLink>
                  </>
                )}

                {isDoctor && (
                  <NavLink to="/doctor" end className={({ isActive }) => `nav-btn ${isActive ? "nav-btn--active" : ""}`}>
                    {t("header.doctorDashboard")}
                  </NavLink>
                )}
              </div>

              <div className="language-switcher header-language-switcher">
                <button type="button" onClick={() => changeLanguage("ua")}>
                  UA
                </button>
                <button type="button" onClick={() => changeLanguage("en")}>
                  EN
                </button>
              </div>

              <div className="header-actions">
                <span className="header-user-name header-user-item">{userName}</span>

                <button type="button" className="nav-register" onClick={logout}>
                  {t("header.logout")}
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="language-switcher">
                <button type="button" onClick={() => changeLanguage("ua")}>
                  UA
                </button>
                <button type="button" onClick={() => changeLanguage("en")}>
                  EN
                </button>
              </div>

              <button type="button" className="nav-btn" onClick={onOpenLogin}>
                {t("header.login")}
              </button>

              <button
                type="button"
                className="nav-register"
                onClick={onOpenRegister}
              >
                {t("header.register")}
              </button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}

export default Header;