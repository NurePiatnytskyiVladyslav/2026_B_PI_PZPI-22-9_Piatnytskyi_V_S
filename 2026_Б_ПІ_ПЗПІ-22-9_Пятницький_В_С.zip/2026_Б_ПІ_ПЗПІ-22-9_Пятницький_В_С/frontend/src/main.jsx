// ---------------------------------
// *Назва файлу: main.jsx*
// *Опис: Точка входу React-застосунку*
// *Що робить: Ініціалізує застосунок та монтує кореневий компонент у DOM*
// ---------------------------------
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import "./styles/global.css";
import "./i18n";
import { AuthProvider } from "./context/AuthContext";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <App />
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
);