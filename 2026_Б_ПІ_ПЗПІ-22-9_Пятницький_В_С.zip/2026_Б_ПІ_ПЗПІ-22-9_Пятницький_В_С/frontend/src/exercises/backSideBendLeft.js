import { calculateAngle } from "../utils/calculateAngle";
import { handleTwoStageExercise } from "./helpers/exerciseHelpers";

const backSideBendLeft = {
  id: "back_side_bend_left",
  name: "Бічний нахил корпусу вліво",
  nameEn: "Side body bend left",
  description: "Вправа допомагає м’яко покращувати рухливість корпусу під час нахилу вліво.",
  descriptionEn: "This exercise helps gently improve trunk mobility with a side bend to the left.",

  analyze: ({ pose, stageRef, setMainAngle, setExerciseStage, setReps }) => {
    const shoulder = pose[11];
    const hip = pose[23];
    const knee = pose[25];

    if (!shoulder || !hip || !knee) {
      setMainAngle(0);
      return "Недостатньо точок для аналізу бічного нахилу корпусу вліво";
    }

    const angle = calculateAngle(shoulder, hip, knee);

    return handleTwoStageExercise({
      angle,
      stageRef,
      setMainAngle,
      setExerciseStage,
      setReps,
      upThreshold: 168,
      downThreshold: 140,
      upText: "Корпус рівно, нахиляйся вліво.",
      downText: "Нахил виконано, повернися у вихідне положення.",
      middleText: "Рухайся повільно та без ривків.",
      repCompleteText: "Повтор зараховано!",
    });
  },
};

export default backSideBendLeft;
