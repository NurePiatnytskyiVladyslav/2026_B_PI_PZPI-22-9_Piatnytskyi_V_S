import { calculateAngle } from "../utils/calculateAngle";
import { areLandmarksVisible } from "../utils/landmarkHelpers";
import { handleTwoStageExercise } from "./helpers/exerciseHelpers";

// Вправа: згинання лівої руки
const leftBiceps = {
  id: "left_biceps",
  name: "Згинання лівої руки",
  nameEn: "Left arm bend",
  description: "Вправа допомагає плавно розробляти рух у лівому ліктьовому суглобі.",
  descriptionEn: "This exercise helps gently restore movement in the left elbow joint.",

  analyze: ({ pose, stageRef, lastRepTimeRef, setMainAngle, setExerciseStage, setReps }) => {
    const shoulder = pose[11];
    const elbow = pose[13];
    const wrist = pose[15];

    if (!shoulder || !elbow || !wrist) {
      setMainAngle(0);
      return "Недостатньо точок для аналізу лівої руки";
    }

    if (!areLandmarksVisible([shoulder, elbow, wrist])) {
      setMainAngle(0);
      return {
        message: "Стань так, щоб ліву руку було краще видно",
        feedback: "Очікую правильне положення перед камерою",
        warning: "Потрібні точки тіла погано видно",
      };
    }

    // Рахуємо кут у лікті
    const angle = calculateAngle(shoulder, elbow, wrist);

    return handleTwoStageExercise({
      angle,
      stageRef,
      setMainAngle,
      setExerciseStage,
      setReps,
      upThreshold: 145,
      downThreshold: 60,
      upStage: "up",
      downStage: "down",
      upText: "Рука розігнута, тепер згинай.",
      downText: "Добре! Тепер розгинай руку.",
      middleText: "Продовжуй рух.",
      repCompleteText: "Повтор зараховано!",
      lastRepTimeRef,
    });
  },
};

export default leftBiceps;