import { calculateAngle } from "../utils/calculateAngle";
import { handleTwoStageExercise } from "./helpers/exerciseHelpers";

const marchingInPlace = {
  id: "marching_in_place",
  name: "Крок на місці",
  nameEn: "Marching in place",
  description: "Вправа допомагає м’яко тренувати координацію та рухливість обох ніг під час кроку на місці.",
  descriptionEn: "This exercise helps gently improve coordination and mobility of both legs with marching.",

  analyze: ({ pose, stageRef, setMainAngle, setExerciseStage, setReps }) => {
    const leftHip = pose[23];
    const leftKnee = pose[25];
    const leftAnkle = pose[27];

    const rightHip = pose[24];
    const rightKnee = pose[26];
    const rightAnkle = pose[28];

    if (!leftHip || !leftKnee || !leftAnkle || !rightHip || !rightKnee || !rightAnkle) {
      setMainAngle(0);
      return "Недостатньо точок для аналізу кроку на місці";
    }

    const leftAngle = calculateAngle(leftHip, leftKnee, leftAnkle);
    const rightAngle = calculateAngle(rightHip, rightKnee, rightAnkle);
    const angle = Math.round(Math.min(leftAngle, rightAngle));

    return handleTwoStageExercise({
      angle,
      stageRef,
      setMainAngle,
      setExerciseStage,
      setReps,
      upThreshold: 165,
      downThreshold: 105,
      upStage: "down",
      downStage: "up",
      upText: "Ноги внизу, піднімай коліно для кроку.",
      downText: "Коліно підняте, опускай та продовжуй крок.",
      middleText: "Рухайся плавно в ритмі кроку.",
      repCompleteText: "Повтор зараховано!",
    });
  },
};

export default marchingInPlace;
