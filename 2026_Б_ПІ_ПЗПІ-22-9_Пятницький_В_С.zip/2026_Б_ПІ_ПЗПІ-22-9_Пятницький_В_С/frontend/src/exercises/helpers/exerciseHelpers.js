// ---------------------------------
// *Назва файлу: exerciseHelpers.js*
// *Опис: Допоміжні функції для вправ*
// *Що робить: Надає утиліти для обчислень і логіки аналізу виконання вправ*
// ---------------------------------
// Універсальна функція для логіки повторень
// feedback оновлюється тільки тоді, коли повтор завершено
export const handleTwoStageExercise = ({
  angle,
  stageRef,
  setMainAngle,
  setExerciseStage,
  setReps,

  upThreshold,
  downThreshold,

  upStage = "up",
  downStage = "down",

  upText = "Верхня позиція",
  downText = "Нижня позиція",
  middleText = "Продовжуй рух",
  repCompleteText = "Повтор зараховано!",

  successFeedback = "Рух виконано добре",
  neutralFeedback = "Виконуй вправу",
  lowRangeFeedback = "Недостатня амплітуда руху",

  minTimeBetweenReps = 700,
  lastRepTimeRef,
  minAngleChange = 0,
  visibilityWarning = "Стань так, щоб потрібні частини тіла було краще видно",
  warning = "",
}) => {
  setMainAngle(angle);

  const isCooldownReady = () => {
    if (!lastRepTimeRef) return true;

    const now = Date.now();
    const lastRepTime = Number(lastRepTimeRef.current || 0);

    return now - lastRepTime >= minTimeBetweenReps;
  };

  const markRepTime = () => {
    if (!lastRepTimeRef) return;
    lastRepTimeRef.current = Date.now();
  };

  const getWarning = () => warning || visibilityWarning || "";

  // Верхня фаза
  if (angle > upThreshold) {
    // Якщо до цього була нижня фаза — повтор завершено
    if (stageRef.current === downStage) {
      const angleDelta = upThreshold - downThreshold;
      const hasEnoughRange = angleDelta >= minAngleChange;

      if (hasEnoughRange && isCooldownReady()) {
        stageRef.current = upStage;
        setExerciseStage(upStage);
        setReps((prev) => prev + 1);
        markRepTime();

        return {
          message: `${repCompleteText} ${upText} Кут: ${angle}°`,
          feedback: successFeedback,
          warning,
        };
      }
    }

    stageRef.current = upStage;
    setExerciseStage(upStage);

    return {
      message: `${upText} Кут: ${angle}°`,
      feedback: neutralFeedback,
      warning: "",
    };
  }

  // Нижня фаза
  if (angle < downThreshold) {
    stageRef.current = downStage;
    setExerciseStage(downStage);

    return {
      message: `${downText} Кут: ${angle}°`,
      feedback: neutralFeedback,
      warning: "",
    };
  }

  // Проміжна фаза
  return {
    message: `${middleText} Кут: ${angle}°`,
    feedback: lowRangeFeedback,
    warning: getWarning(),
  };
};