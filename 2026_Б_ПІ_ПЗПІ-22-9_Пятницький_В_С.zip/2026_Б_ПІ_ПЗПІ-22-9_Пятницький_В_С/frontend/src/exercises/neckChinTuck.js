import { calculateAngle } from "../utils/calculateAngle";
import { handleTwoStageExercise } from "./helpers/exerciseHelpers";
import { areLandmarksVisible } from "../utils/landmarkHelpers";

const neckChinTuck = {
  id: "neck_chin_tuck",
  name: "Підборіддя до шиї",
  nameEn: "Neck chin tuck",
  description: "Вправа допомагає м’яко активувати глибокі м’язи шиї при контрольованому русі підборіддя назад.",
  descriptionEn: "This exercise helps gently activate deep neck muscles with a controlled chin tuck.",

  analyze: ({
    pose,
    stageRef,
    setMainAngle,
    setExerciseStage,
    setReps,
    lastRepTimeRef,
  }) => {
    const nose = pose[0];
    const leftShoulder = pose[11];
    const rightShoulder = pose[12];
    const leftHip = pose[23];
    const rightHip = pose[24];

    if (!nose || !leftShoulder || !rightShoulder) {
      setMainAngle(0);
      return "Недостатньо точок для аналізу вправи підборіддя до шиї";
    }

    if (!areLandmarksVisible([nose, leftShoulder, rightShoulder], 0.5)) {
      setMainAngle(0);
      return "Сядьте так, щоб було видно обличчя і плечі";
    }

    const shoulder = {
      x: (leftShoulder.x + rightShoulder.x) / 2,
      y: (leftShoulder.y + rightShoulder.y) / 2,
    };
    const hip =
      leftHip && rightHip
        ? {
            x: (leftHip.x + rightHip.x) / 2,
            y: (leftHip.y + rightHip.y) / 2,
          }
        : {
            x: shoulder.x,
            y: shoulder.y + 0.2,
          };

    const angle = calculateAngle(nose, shoulder, hip);

    return handleTwoStageExercise({
      angle,
      stageRef,
      lastRepTimeRef,
      setMainAngle,
      setExerciseStage,
      setReps,
      upThreshold: 168,
      downThreshold: 152,
      upText: "Голова нейтрально, м’яко потягни підборіддя назад.",
      downText: "Позицію виконано, повернися у нейтральне положення.",
      middleText: "Поверніться у нейтральне положення",
      repCompleteText: "Повтор зараховано!",
      minTimeBetweenReps: 1300,
      tooFastText: "Виконуйте рух повільно",
    });
  },
};

export default neckChinTuck;
