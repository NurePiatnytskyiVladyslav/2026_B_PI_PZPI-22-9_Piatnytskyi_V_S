import { areLandmarksVisible } from "../utils/landmarkHelpers";

// Вправа: нахил голови вправо
const neckSideRight = {
  id: "neck_side_right",
  name: "Нахил голови вправо",
  nameEn: "Neck side bend right",
  description: "Вправа допомагає плавно розробляти бічний нахил шиї вправо.",
  descriptionEn: "This exercise helps gently improve neck mobility by bending to the right.",

  analyze: ({
    pose,
    stageRef,
    setMainAngle,
    setExerciseStage,
    setReps,
    lastRepTimeRef,
  }) => {
    const nose = pose[0];
    const rightShoulder = pose[12];
    const leftShoulder = pose[11];
    const neutralThreshold = 0.1;
    const targetThreshold = 0.16;
    const minShoulderWidth = 0.05;
    const minTimeBetweenReps = 1200;

    if (!nose || !rightShoulder || !leftShoulder) {
      setMainAngle(0);
      setExerciseStage("neutral");
      return "Сядьте так, щоб було видно обличчя і плечі";
    }

    if (!areLandmarksVisible([nose, leftShoulder, rightShoulder], 0.5)) {
      setMainAngle(0);
      setExerciseStage("neutral");
      return "Сядьте так, щоб було видно обличчя і плечі";
    }

    const shoulderWidth = Math.abs(leftShoulder.x - rightShoulder.x);
    if (!Number.isFinite(shoulderWidth) || shoulderWidth < minShoulderWidth) {
      setMainAngle(0);
      setExerciseStage("neutral");
      return "Сядьте рівно ближче до камери";
    }

    const shoulderTilt = Math.abs(leftShoulder.y - rightShoulder.y) / shoulderWidth;
    const midShoulderX = (leftShoulder.x + rightShoulder.x) / 2;
    const noseOffset = (nose.x - midShoulderX) / shoulderWidth;

    setMainAngle(Math.round(Math.abs(noseOffset) * 100));

    const inNeutral = Math.abs(noseOffset) < neutralThreshold;
    const inTarget = noseOffset > targetThreshold;
    const isCooldown = Date.now() - lastRepTimeRef.current < minTimeBetweenReps;

    if (!stageRef.current) {
      stageRef.current = "neutral";
    }

    let feedback = "Нахиліть голову трохи більше";

    if (inNeutral) {
      if (stageRef.current === "target") {
        if (!isCooldown) {
          setReps((prev) => prev + 1);
          lastRepTimeRef.current = Date.now();
          feedback = "Повторення зараховано";
        } else {
          feedback = "Почніть рух повільно";
        }
      } else {
        feedback = "Почніть рух повільно";
      }
      stageRef.current = "neutral";
      setExerciseStage("neutral");
    } else if (inTarget) {
      stageRef.current = "target";
      setExerciseStage("target");
      feedback = "Рух хороший, поверніться назад";
    } else {
      setExerciseStage(stageRef.current === "target" ? "target" : "neutral");
    }

    if (shoulderTilt > 0.22) {
      return "Тримайте плечі рівно";
    }

    return feedback;
  },
};

export default neckSideRight;
