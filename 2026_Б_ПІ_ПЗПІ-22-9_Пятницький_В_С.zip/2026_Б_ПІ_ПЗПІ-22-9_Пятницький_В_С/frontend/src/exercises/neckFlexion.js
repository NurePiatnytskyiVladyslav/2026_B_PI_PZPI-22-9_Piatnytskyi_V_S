import { calculateAngle } from "../utils/calculateAngle";
import { handleTwoStageExercise } from "./helpers/exerciseHelpers";
import { areLandmarksVisible } from "../utils/landmarkHelpers";

// Вправа: нахил голови вперед
const neckFlexion = {
  id: "neck_flexion",
  name: "Нахил голови вперед",
  nameEn: "Neck flexion",
  description: "Вправа допомагає м’яко покращувати рухливість шиї під час нахилу голови вперед.",
  descriptionEn: "This exercise helps gently improve neck mobility by bending forward.",

  analyze: ({
    pose,
    stageRef,
    setMainAngle,
    setExerciseStage,
    setReps,
    lastRepTimeRef,
  }) => {
    const nose = pose[0];
    const leftShoulder = pose[11];
    const rightShoulder = pose[12];
    const leftHip = pose[23];
    const rightHip = pose[24];

    if (!nose || !leftShoulder || !rightShoulder) {
      setMainAngle(0);
      return "Недостатньо точок для аналізу нахилу голови вперед";
    }

    if (!areLandmarksVisible([nose, leftShoulder, rightShoulder], 0.5)) {
      setMainAngle(0);
      return "Сядьте так, щоб було видно обличчя і плечі";
    }

    const shoulder = {
      x: (leftShoulder.x + rightShoulder.x) / 2,
      y: (leftShoulder.y + rightShoulder.y) / 2,
    };
    const hip =
      leftHip && rightHip
        ? {
            x: (leftHip.x + rightHip.x) / 2,
            y: (leftHip.y + rightHip.y) / 2,
          }
        : {
            x: shoulder.x,
            y: shoulder.y + 0.2,
          };

    const angle = calculateAngle(nose, shoulder, hip);

    return handleTwoStageExercise({
      angle,
      stageRef,
      lastRepTimeRef,
      setMainAngle,
      setExerciseStage,
      setReps,
      upThreshold: 170,
      downThreshold: 135,
      upText: "Голова рівно, нахиляй вперед.",
      downText: "Голова нахилена, поверни назад.",
      middleText: "Поверніться у нейтральне положення",
      repCompleteText: "Повтор зараховано!",
      minTimeBetweenReps: 1200,
      tooFastText: "Виконуйте рух повільно",
    });
  },
};

export default neckFlexion;
