import { calculateAngle } from "../utils/calculateAngle";
import { handleTwoStageExercise } from "./helpers/exerciseHelpers";
import { areLandmarksVisible } from "../utils/landmarkHelpers";

// Вправа: нахил голови назад
const neckExtension = {
  id: "neck_extension",
  name: "Нахил голови назад",
  nameEn: "Neck extension",
  description: "Вправа допомагає плавно покращувати рухливість шиї під час нахилу голови назад.",
  descriptionEn: "This exercise helps gently improve neck mobility by extending backward.",

  analyze: ({
    pose,
    stageRef,
    setMainAngle,
    setExerciseStage,
    setReps,
    lastRepTimeRef,
  }) => {
    const nose = pose[0];
    const leftShoulder = pose[11];
    const rightShoulder = pose[12];
    const leftHip = pose[23];
    const rightHip = pose[24];

    if (!nose || !leftShoulder || !rightShoulder) {
      setMainAngle(0);
      return "Недостатньо точок для аналізу нахилу голови назад";
    }

    if (!areLandmarksVisible([nose, leftShoulder, rightShoulder], 0.5)) {
      setMainAngle(0);
      return "Сядьте так, щоб було видно обличчя і плечі";
    }

    const shoulder = {
      x: (leftShoulder.x + rightShoulder.x) / 2,
      y: (leftShoulder.y + rightShoulder.y) / 2,
    };
    const hip =
      leftHip && rightHip
        ? {
            x: (leftHip.x + rightHip.x) / 2,
            y: (leftHip.y + rightHip.y) / 2,
          }
        : {
            x: shoulder.x,
            y: shoulder.y + 0.2,
          };

    const angle = calculateAngle(nose, shoulder, hip);

    return handleTwoStageExercise({
      angle,
      stageRef,
      lastRepTimeRef,
      setMainAngle,
      setExerciseStage,
      setReps,
      upThreshold: 160,
      downThreshold: 125,
      upStage: "down",
      downStage: "up",
      upText: "Голова прямо, відхиляй назад.",
      downText: "Голова назад, поверни вперед.",
      middleText: "Поверніться у нейтральне положення",
      repCompleteText: "Повтор зараховано!",
      minTimeBetweenReps: 1200,
      tooFastText: "Виконуйте рух повільно",
    });
  },
};

export default neckExtension;
