import { calculateAngle } from "../utils/calculateAngle";
import { areLandmarksVisible } from "../utils/landmarkHelpers";
import { handleTwoStageExercise } from "./helpers/exerciseHelpers";

const bothBiceps = {
  id: "both_biceps",
  name: "Згинання обох рук",
  nameEn: "Both arms bend",
  description: "Вправа допомагає м’яко розробляти ліктьові суглоби одночасно для обох рук.",
  descriptionEn: "This exercise helps gently restore elbow movement on both sides at the same time.",

  analyze: ({ pose, stageRef, lastRepTimeRef, setMainAngle, setExerciseStage, setReps }) => {
    const leftShoulder = pose[11];
    const leftElbow = pose[13];
    const leftWrist = pose[15];

    const rightShoulder = pose[12];
    const rightElbow = pose[14];
    const rightWrist = pose[16];

    if (!leftShoulder || !leftElbow || !leftWrist || !rightShoulder || !rightElbow || !rightWrist) {
      setMainAngle(0);
      return "Недостатньо точок для аналізу згинання обох рук";
    }

    if (!areLandmarksVisible([leftShoulder, leftElbow, leftWrist, rightShoulder, rightElbow, rightWrist])) {
      setMainAngle(0);
      return {
        message: "Стань так, щоб обидві руки було видно",
        feedback: "Очікую правильне положення перед камерою",
        warning: "Потрібні точки тіла погано видно",
      };
    }

    const leftAngle = calculateAngle(leftShoulder, leftElbow, leftWrist);
    const rightAngle = calculateAngle(rightShoulder, rightElbow, rightWrist);
    const angle = Math.round((leftAngle + rightAngle) / 2);

    return handleTwoStageExercise({
      angle,
      stageRef,
      setMainAngle,
      setExerciseStage,
      setReps,
      upThreshold: 145,
      downThreshold: 65,
      upStage: "up",
      downStage: "down",
      upText: "Руки розігнуті, тепер згинай обидві.",
      downText: "Добре! Тепер плавно розгинай обидві руки.",
      middleText: "Продовжуй рух обома руками.",
      repCompleteText: "Повтор зараховано!",
      lastRepTimeRef,
    });
  },
};

export default bothBiceps;
