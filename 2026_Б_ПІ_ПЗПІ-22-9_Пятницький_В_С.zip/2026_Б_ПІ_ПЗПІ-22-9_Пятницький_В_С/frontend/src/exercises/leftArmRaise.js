import { calculateAngle } from "../utils/calculateAngle";
import { areLandmarksVisible } from "../utils/landmarkHelpers";
import { handleTwoStageExercise } from "./helpers/exerciseHelpers";

// Вправа: підйом лівої руки в сторону
const leftArmRaise = {
  id: "left_arm_raise",
  name: "Підйом лівої руки в сторону",
  nameEn: "Left arm side raise",
  description: "Вправа допомагає плавно розробляти рух лівої руки у плечі.",
  descriptionEn: "This exercise helps improve left shoulder mobility with a side raise.",

  analyze: ({ pose, stageRef, lastRepTimeRef, setMainAngle, setExerciseStage, setReps }) => {
    const elbow = pose[13];
    const shoulder = pose[11];
    const hip = pose[23];

    if (!elbow || !shoulder || !hip) {
      setMainAngle(0);
      return "Недостатньо точок для аналізу підйому лівої руки";
    }

    // Рахуємо кут у плечі
    if (!areLandmarksVisible([elbow, shoulder, hip])) {
      setMainAngle(0);
      return {
        message: "Стань так, щоб ліву руку було краще видно",
        feedback: "Очікую правильне положення перед камерою",
        warning: "Потрібні точки тіла погано видно",
      };
    }

    const angle = calculateAngle(elbow, shoulder, hip);

    return handleTwoStageExercise({
      angle,
      stageRef,
      setMainAngle,
      setExerciseStage,
      setReps,
      upThreshold: 70,
      downThreshold: 25,
      upStage: "up",
      downStage: "down",
      upText: "Рука піднята, тепер опускай.",
      downText: "Рука внизу, піднімай в сторону.",
      middleText: "Піднімай або опускай руку плавно.",
      repCompleteText: "Повтор зараховано!",
      lastRepTimeRef,
    });
  },
};

export default leftArmRaise;