import { calculateAngle } from "../utils/calculateAngle";
import { areLandmarksVisible } from "../utils/landmarkHelpers";
import { handleTwoStageExercise } from "./helpers/exerciseHelpers";

// Вправа: підйом правої руки в сторону
const rightArmRaise = {
  id: "right_arm_raise",
  name: "Підйом правої руки в сторону",
  nameEn: "Right arm side raise",
  description: "Вправа допомагає плавно розробляти рух правої руки у плечі.",
  descriptionEn: "This exercise helps improve right shoulder mobility with a side raise.",

  analyze: ({ pose, stageRef, lastRepTimeRef, setMainAngle, setExerciseStage, setReps }) => {
    const elbow = pose[14];
    const shoulder = pose[12];
    const hip = pose[24];

    if (!elbow || !shoulder || !hip) {
      setMainAngle(0);
      return {
        message: "Недостатньо точок для аналізу підйому руки",
        feedback: "Очікую правильне положення",
        warning: "",
      };
    }

    if (!areLandmarksVisible([elbow, shoulder, hip])) {
      setMainAngle(0);
      return {
        message: "Стань так, щоб руку було краще видно",
        feedback: "Очікую правильне положення перед камерою",
        warning: "Потрібні точки тіла погано видно",
      };
    }

    const angle = calculateAngle(elbow, shoulder, hip);

    let warning = "";

    // Попередження тільки коли рука вже рухається,
    // але ще не дійшла до нормальної амплітуди
    if (angle >= 25 && angle < 55) {
      warning = "Підніми руку трохи вище";
    }

    return handleTwoStageExercise({
      angle,
      stageRef,
      setMainAngle,
      setExerciseStage,
      setReps,

      upThreshold: 70,
      downThreshold: 25,

      upStage: "up",
      downStage: "down",

      upText: "Рука піднята, тепер опускай.",
      downText: "Рука внизу, піднімай в сторону.",
      middleText: "Піднімай або опускай руку плавно.",
      repCompleteText: "Повтор зараховано!",

      successFeedback: "Рух виконано добре",
      neutralFeedback: "Виконуй вправу",
      lowRangeFeedback: "Недостатня амплітуда руху",

      warning,
      lastRepTimeRef,
    });
  },
};


export default rightArmRaise;