import { calculateAngle } from "../utils/calculateAngle";
import { areLandmarksVisible } from "../utils/landmarkHelpers";
import { handleTwoStageExercise } from "./helpers/exerciseHelpers";

// Вправа: згинання правої руки
const rightBiceps = {
  id: "right_biceps",
  name: "Згинання правої руки",
  nameEn: "Right arm bend",
  description: "Вправа допомагає плавно розробляти рух у правому ліктьовому суглобі.",
  descriptionEn: "This exercise helps gently restore movement in the right elbow joint.",

  analyze: ({ pose, stageRef, lastRepTimeRef, setMainAngle, setExerciseStage, setReps }) => {
    const shoulder = pose[12];
    const elbow = pose[14];
    const wrist = pose[16];

    if (!shoulder || !elbow || !wrist) {
      setMainAngle(0);
      return "Недостатньо точок для аналізу правої руки";
    }

    if (!areLandmarksVisible([shoulder, elbow, wrist])) {
      setMainAngle(0);
      return {
        message: "Стань так, щоб руку було краще видно",
        feedback: "Очікую правильне положення перед камерою",
        warning: "Потрібні точки тіла погано видно",
      };
    }

    // Рахуємо кут у лікті
    const angle = calculateAngle(shoulder, elbow, wrist);

    return handleTwoStageExercise({
      angle,
      stageRef,
      setMainAngle,
      setExerciseStage,
      setReps,
      upThreshold: 145,
      downThreshold: 60,
      upStage: "up",
      downStage: "down",
      upText: "Рука розігнута, тепер згинай.",
      downText: "Добре! Тепер розгинай руку.",
      middleText: "Продовжуй рух.",
      repCompleteText: "Повтор зараховано!",
      lastRepTimeRef,
    });
  },
};

export default rightBiceps;