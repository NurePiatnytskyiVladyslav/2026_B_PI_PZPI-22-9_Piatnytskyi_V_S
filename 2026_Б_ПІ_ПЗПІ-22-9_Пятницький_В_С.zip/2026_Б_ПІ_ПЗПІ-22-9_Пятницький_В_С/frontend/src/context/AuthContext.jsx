// ---------------------------------
// *Назва файлу: AuthContext.jsx*
// *Опис: Контекст автентифікації користувача*
// *Що робить: Керує станом користувача, входом, реєстрацією та виходом із системи*
// ---------------------------------
import { useCallback, useEffect, useState } from "react";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { auth } from "../firebase/firebase";
import {
  createUserProfileIfNotExists,
  getUserProfile,
} from "../services/userService";
import { AuthContext } from "./auth-context";

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const refreshUserProfile = useCallback(async (userId) => {
    if (!userId) return null;
    const profile = await getUserProfile(userId);
    setUserProfile(profile);
    return profile;
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setLoading(true);

      if (!currentUser) {
        setUser(null);
        setUserProfile(null);
        setLoading(false);
        return;
      }

      setUser(currentUser);

      let profile = await refreshUserProfile(currentUser.uid);
      if (!profile) {
        profile = await createUserProfileIfNotExists(currentUser);
      }

      setUserProfile(profile);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [refreshUserProfile]);

  const logout = async () => {
    await signOut(auth);
  };

  const role = userProfile?.role || null;

  const value = {
    user,
    userProfile,
    role,
    isDoctor: role === "doctor",
    isPatient: role === "patient",
    loading,
    logout,
    refreshUserProfile,
  };

  if (loading) {
    return null;
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}