import { useEffect, useRef, useState } from "react";

function useStableValue(value, delayMs = 400) {
  const [stableValue, setStableValue] = useState(value);
  const timeoutRef = useRef(null);

  useEffect(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    if (value === stableValue) {
      return undefined;
    }

    timeoutRef.current = setTimeout(() => {
      setStableValue(value);
      timeoutRef.current = null;
    }, delayMs);

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    };
  }, [value, delayMs, stableValue]);

  return stableValue;
}

export default useStableValue;
