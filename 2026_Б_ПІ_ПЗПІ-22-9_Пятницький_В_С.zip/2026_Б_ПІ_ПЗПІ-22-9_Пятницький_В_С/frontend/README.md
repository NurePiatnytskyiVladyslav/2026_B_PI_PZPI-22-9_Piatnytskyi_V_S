# Frontend rehabilitationAI

Frontend-частина застосунку rehabilitationAI (React + Vite).

## Запуск
```bash
npm install
cp .env.example .env
npm run dev
```

## Перевірка
```bash
npm run lint
npm run build
```

## Примітка
Актуальна авторизація в UI реалізована через `AuthModal` на головній сторінці.
